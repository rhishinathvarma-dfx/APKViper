Place three PNG icons here before loading the extension:

  icon16.png   (16x16)
  icon48.png   (48x48)
  icon128.png  (128x128)

A simple dog/hound or magnifying-glass emoji rendered to PNG works fine.
The extension will load without them, but Chrome will show a default icon
and may warn about the missing files.

