// ReconHound — Fingerprint signature database
// Maps response headers, cookies, and DOM markers to technologies.

export const HEADER_SIGNATURES = {
  "server": [
    { regex: /nginx\/?([\d.]+)?/i, tech: "nginx", category: "web-server" },
    { regex: /apache\/?([\d.]+)?/i, tech: "Apache", category: "web-server" },
    { regex: /microsoft-iis\/?([\d.]+)?/i, tech: "IIS", category: "web-server" },
    { regex: /litespeed/i, tech: "LiteSpeed", category: "web-server" },
    { regex: /caddy/i, tech: "Caddy", category: "web-server" },
    { regex: /cloudflare/i, tech: "Cloudflare", category: "cdn-waf" }
  ],
  "x-powered-by": [
    { regex: /php\/?([\d.]+)?/i, tech: "PHP", category: "language" },
    { regex: /express/i, tech: "Express", category: "backend" },
    { regex: /asp\.net/i, tech: "ASP.NET", category: "backend" },
    { regex: /next\.js/i, tech: "Next.js", category: "frontend" },
    { regex: /servlet/i, tech: "Java Servlet", category: "backend" }
  ],
  "x-aspnet-version": [
    { regex: /([\d.]+)/, tech: "ASP.NET", category: "backend" }
  ],
  "x-generator": [
    { regex: /drupal\s?([\d.]+)?/i, tech: "Drupal", category: "cms" },
    { regex: /wordpress\s?([\d.]+)?/i, tech: "WordPress", category: "cms" }
  ],
  "x-drupal-cache": [
    { regex: /.*/i, tech: "Drupal", category: "cms" }
  ],
  "x-shopify-stage": [
    { regex: /.*/i, tech: "Shopify", category: "cms" }
  ]
};

export const COOKIE_SIGNATURES = [
  { regex: /laravel_session/i, tech: "Laravel", category: "backend" },
  { regex: /csrftoken|sessionid/i, tech: "Django", category: "backend" },
  { regex: /JSESSIONID/i, tech: "Java/JSP", category: "backend" },
  { regex: /PHPSESSID/i, tech: "PHP", category: "language" },
  { regex: /ci_session/i, tech: "CodeIgniter", category: "backend" },
  { regex: /_rails|_session_id/i, tech: "Ruby on Rails", category: "backend" },
  { regex: /connect\.sid/i, tech: "Express", category: "backend" },
  { regex: /wordpress_logged_in|wp-settings/i, tech: "WordPress", category: "cms" }
];

// DB inference (best-effort, from error strings on the page)
export const DB_ERROR_SIGNATURES = [
  { regex: /sqlstate|mysql_fetch|you have an error in your sql|mysqli/i, tech: "MySQL", category: "database" },
  { regex: /pg_query|psql|postgresql|pg_connect/i, tech: "PostgreSQL", category: "database" },
  { regex: /ora-\d{5}/i, tech: "Oracle", category: "database" },
  { regex: /sqlite_|sqlite3/i, tech: "SQLite", category: "database" },
  { regex: /mongodb|bson|mongoose/i, tech: "MongoDB", category: "database" },
  { regex: /microsoft sql server|sql server|incorrect syntax near/i, tech: "Microsoft SQL Server", category: "database" }
];

