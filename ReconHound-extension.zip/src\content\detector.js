// ReconHound — In-page detector (content script)
// Detects client-side frameworks and scrapes the DOM for DB error leaks.

(function () {
  function detectFrontend() {
    const stack = [];

    if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__ || document.querySelector("[data-reactroot]")) {
      stack.push({ tech: "React", version: null, category: "frontend" });
    }
    if (window.__VUE__ || document.querySelector("[data-v-app]") || window.Vue) {
      stack.push({ tech: "Vue.js", version: window.Vue?.version || null, category: "frontend" });
    }
    const ng = document.querySelector("[ng-version]");
    if (ng) stack.push({ tech: "Angular", version: ng.getAttribute("ng-version"), category: "frontend" });

    if (window.jQuery?.fn?.jquery) {
      stack.push({ tech: "jQuery", version: window.jQuery.fn.jquery, category: "frontend" });
    }
    if (document.querySelector("[data-svelte-h], [class*='svelte-']")) {
      stack.push({ tech: "Svelte", version: null, category: "frontend" });
    }
    if (window.__NEXT_DATA__ || document.querySelector("#__next")) {
      stack.push({ tech: "Next.js", version: null, category: "frontend" });
    }
    if (window.__NUXT__ || document.querySelector("#__nuxt")) {
      stack.push({ tech: "Nuxt.js", version: null, category: "frontend" });
    }
    if (window.Backbone) {
      stack.push({ tech: "Backbone.js", version: window.Backbone.VERSION || null, category: "frontend" });
    }
    if (window.bootstrap || document.querySelector("[class*='col-'], .navbar-toggler")) {
      stack.push({ tech: "Bootstrap", version: null, category: "frontend" });
    }
    return stack;
  }

  function scrapeBody() {
    return document.body?.innerText?.slice(0, 50000) || "";
  }

  // Collect REAL loaded resource URLs (scripts + stylesheets) for library scan.
  function collectResourceUrls() {
    const urls = [];
    document.querySelectorAll("script[src]").forEach((s) => urls.push(s.src));
    document.querySelectorAll("link[rel='stylesheet'][href]").forEach((l) => urls.push(l.href));
    // Also include performance entries (catches dynamically loaded scripts).
    try {
      performance.getEntriesByType("resource").forEach((e) => {
        if (/\.(js|css)(\?|$)/i.test(e.name)) urls.push(e.name);
      });
    } catch (_) {}
    return [...new Set(urls)];
  }

  // Collect inline <script> contents + raw HTML for passive secret scanning.
  function collectInlineCode() {
    let code = "";
    document.querySelectorAll("script:not([src])").forEach((s) => {
      code += "\n" + (s.textContent || "");
    });
    return code.slice(0, 500000);
  }

  // Detection runs in an isolated world, so window.* checks for page globals
  // can be unreliable. We inject a small script into the page world to read them.
  function injectPageProbe() {
    try {
      const script = document.createElement("script");
      script.textContent = `(${pageProbe.toString()})();`;
      (document.head || document.documentElement).appendChild(script);
      script.remove();
    } catch (e) {
      // ignore CSP failures; header/DOM detection still works
    }
  }

  function pageProbe() {
    const found = [];
    if (window.React?.version) found.push({ tech: "React", version: window.React.version, category: "js-library" });
    if (window.Vue?.version) found.push({ tech: "Vue.js", version: window.Vue.version, category: "js-library" });
    if (window.jQuery?.fn?.jquery) found.push({ tech: "jQuery", version: window.jQuery.fn.jquery, category: "js-library" });
    if (window.angular?.version?.full) found.push({ tech: "AngularJS", version: window.angular.version.full, category: "js-library" });
    if (window._?.VERSION) found.push({ tech: "lodash", version: window._.VERSION, category: "js-library" });
    if (window.moment?.version) found.push({ tech: "Moment.js", version: window.moment.version, category: "js-library" });
    if (window.axios?.VERSION) found.push({ tech: "Axios", version: window.axios.VERSION, category: "js-library" });
    if (window.d3?.version) found.push({ tech: "D3.js", version: window.d3.version, category: "js-library" });
    if (window.Chart?.version) found.push({ tech: "Chart.js", version: window.Chart.version, category: "js-library" });
    if (window.bootstrap?.Tooltip?.VERSION) found.push({ tech: "Bootstrap", version: window.bootstrap.Tooltip.VERSION, category: "js-library" });
    if (window.THREE?.REVISION) found.push({ tech: "Three.js", version: String(window.THREE.REVISION), category: "js-library" });
    window.postMessage({ __reconhound: true, globals: found }, "*");
  }

  window.addEventListener("message", (e) => {
    if (e.source === window && e.data?.__reconhound) {
      chrome.runtime.sendMessage({
        type: "RH_GLOBALS",
        url: location.href,
        globals: e.data.globals || []
      });
    }
  });

  injectPageProbe();

  function runScan() {
    injectPageProbe();
    chrome.runtime.sendMessage({
      type: "RH_FRONTEND",
      url: location.href,
      frontend: detectFrontend(),
      scriptUrls: collectResourceUrls(),
      inlineCode: collectInlineCode(),
      bodyText: scrapeBody()
    });
  }

  runScan();

  // Only wire SPA hooks & listeners once, even if the script is re-injected
  // (the popup re-injects this file to force a fresh scan).
  if (!window.__reconhoundWired) {
    window.__reconhoundWired = true;

    let rescanTimer = null;
    function scheduleRescan() {
      clearTimeout(rescanTimer);
      rescanTimer = setTimeout(runScan, 800);
    }
    const _push = history.pushState;
    const _replace = history.replaceState;
    history.pushState = function (...args) { _push.apply(this, args); scheduleRescan(); };
    history.replaceState = function (...args) { _replace.apply(this, args); scheduleRescan(); };
    window.addEventListener("popstate", scheduleRescan);
    window.addEventListener("hashchange", scheduleRescan);

    // Expose for re-injection so executeScript can just call rescan.
    window.__reconhoundRescan = runScan;
  } else if (typeof window.__reconhoundRescan === "function") {
    window.__reconhoundRescan();
  }
})();

