// ReconHound — Service worker (background)
// Captures headers/cookies, merges with content-script data, runs CVE matching.

import { HEADER_SIGNATURES, COOKIE_SIGNATURES, DB_ERROR_SIGNATURES } from "../engine/fingerprints.js";
import { lookupCVEs } from "../engine/cve-matcher.js";
import { analyzeSecurityHeaders, analyzeCookies, analyzeCors } from "../engine/security-analyzer.js";
import { scanScriptUrls, mergeGlobals } from "../engine/js-libraries.js";
import { probePaths } from "../engine/path-prober.js";
import { scanText } from "../engine/secret-scanner.js";
import { checkExposures } from "../engine/exposure-checker.js";
import { extractEndpoints, extractSubdomains, extractParams } from "../engine/endpoint-extractor.js";
import { checkSourceMaps, checkGraphQL } from "../engine/probe-advanced.js";
import { computeRisk } from "../engine/risk-score.js";
import { saveSnapshot, listSnapshots, diffSnapshots, snapshotOf, clearHistory } from "../engine/history.js";
import { enrichCves } from "../engine/exploit-intel.js";
import { reflectionProbe, directoryListingProbe } from "../engine/safe-checks.js";
import { runBrain } from "../engine/ai-brain.js";

const SEVERITY_WEIGHT = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1, UNKNOWN: 0 };

const tabData = {}; // { tabId: { url, tech: [], security: [] } }

// MV3 service workers sleep and lose memory. Mirror tabData to session storage
// so results survive worker restarts within the browsing session.
const SESSION_KEY = "rh_tabs";
let persistTimer = null;
function persistTabs() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    try { chrome.storage.session.set({ [SESSION_KEY]: tabData }); } catch (_) {}
  }, 300);
}
// Rehydrate on startup.
const ready = (async () => {
  try {
    const d = await chrome.storage.session.get(SESSION_KEY);
    if (d[SESSION_KEY]) Object.assign(tabData, d[SESSION_KEY]);
  } catch (_) {}
})();

// Cached settings (kept in sync with chrome.storage.local)
const settings = {
  nvdApiKey: "",
  enableCves: true,
  enableSecurity: true,
  enableSecrets: true,
  enableBadge: true,
  customSecretRules: []
};

chrome.storage.local.get(settings).then((cfg) => Object.assign(settings, cfg));
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  for (const [k, { newValue }] of Object.entries(changes)) {
    if (k in settings) settings[k] = newValue;
  }
});

function ensureTab(tabId) {
  tabData[tabId] ??= { tech: [], security: [] };
  return tabData[tabId];
}

function addTech(tabId, entry) {
  if (tabId == null || tabId < 0) return;
  const d = ensureTab(tabId);
  const exists = d.tech.find(
    (t) => t.tech === entry.tech && t.category === entry.category
  );
  if (!exists) d.tech.push(entry);
  else if (entry.version && !exists.version) exists.version = entry.version;
  persistTabs();
}

function addSecrets(tabId, secrets) {
  if (!secrets?.length) return;
  const d = ensureTab(tabId);
  d.secrets ??= [];
  const seen = new Set(d.secrets.map((s) => s.id + s.match));
  for (const s of secrets) {
    const key = s.id + s.match;
    if (!seen.has(key)) {
      seen.add(key);
      d.secrets.push(s);
    }
  }
  const weight = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1, UNKNOWN: 0 };
  d.secrets.sort((a, b) => (weight[b.severity] || 0) - (weight[a.severity] || 0));
  persistTabs();
}

// Fetch external same-origin JS bundles (capped) and scan them for secrets.
async function scanExternalScripts(tabId, scriptUrls, pageOrigin) {
  const jsUrls = (scriptUrls || []).filter((u) => /\.js(\?|$)/i.test(u)).slice(0, 8);
  await Promise.all(
    jsUrls.map(async (url) => {
      try {
        const res = await fetch(url, { credentials: "omit" });
        if (!res.ok) return;
        const text = (await res.text()).slice(0, 1000000);
        addSecrets(tabId, scanText(text, shortenUrl(url), settings.customSecretRules));
        addEndpoints(tabId, extractEndpoints(text, shortenUrl(url)));
        addRecon(tabId, {
          subdomains: extractSubdomains(text, baseHostOf(pageOrigin)),
          params: extractParams(text)
        });
        updateBadge(tabId);
      } catch (_) {}
    })
  );
}

function addEndpoints(tabId, endpoints) {
  if (!endpoints?.length) return;
  const d = ensureTab(tabId);
  d.endpoints ??= [];
  const seen = new Set(d.endpoints.map((e) => e.path));
  for (const e of endpoints) {
    if (!seen.has(e.path)) {
      seen.add(e.path);
      d.endpoints.push(e);
    }
  }
  const order = { graphql: 0, admin: 1, auth: 2, api: 3, data: 4, link: 5 };
  d.endpoints.sort((a, b) => (order[a.type] ?? 9) - (order[b.type] ?? 9));
  persistTabs();
}

function addRecon(tabId, { subdomains = [], params = [] }) {
  const d = ensureTab(tabId);
  d.subdomains ??= [];
  d.params ??= [];
  const subSet = new Set(d.subdomains);
  subdomains.forEach((s) => subSet.add(s));
  d.subdomains = [...subSet].sort().slice(0, 300);
  const paramSet = new Set(d.params);
  params.forEach((p) => paramSet.add(p));
  d.params = [...paramSet].sort().slice(0, 300);
  persistTabs();
}

function baseHostOf(url) {
  try { return new URL(url).hostname; } catch (_) { return ""; }
}

// Header fallback: when the worker missed onHeadersReceived (e.g. page was
// already open or worker was asleep), re-fetch the page and fingerprint headers.
async function headerFallback(tabId, url) {
  try {
    const res = await fetch(url, { credentials: "omit", redirect: "follow" });
    const headers = [];
    res.headers.forEach((value, name) => headers.push({ name, value }));

    for (const h of headers) {
      const name = h.name.toLowerCase();
      const sigs = HEADER_SIGNATURES[name];
      if (sigs) {
        for (const sig of sigs) {
          const m = (h.value || "").match(sig.regex);
          if (m) addTech(tabId, { tech: sig.tech, version: m[1] || null, category: sig.category });
        }
      }
    }

    if (settings.enableSecurity) {
      const d = ensureTab(tabId);
      const sec = [
        ...analyzeSecurityHeaders(headers),
        ...analyzeCors(headers)
      ].sort((a, b) => (SEVERITY_WEIGHT[b.severity] || 0) - (SEVERITY_WEIGHT[a.severity] || 0));
      // Only set if we don't already have richer header-listener data.
      if (!d.security || d.security.length === 0) d.security = sec;
    }
    persistTabs();
  } catch (_) {}
}

// Force a fresh scan on demand (popup open). Re-injects the content detector to
// re-collect DOM/JS, and runs the header fallback if needed.
async function ensureFreshScan(tabId, url) {
  if (!url || /^(chrome|edge|about|chrome-extension|view-source):/i.test(url)) return;
  const d = ensureTab(tabId);
  d.url = url;

  // 1. Re-run the in-page detector (DOM frameworks, script URLs, inline secrets).
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["src/content/detector.js"]
    });
  } catch (_) {}

  // 2. Give the content script a moment to message back, then header fallback.
  await new Promise((r) => setTimeout(r, 350));
  const hasHeaderTech = (d.tech || []).some((t) =>
    ["web-server", "language", "backend", "cms"].includes(t.category)
  );
  if (!hasHeaderTech || !d.security || d.security.length === 0) {
    await headerFallback(tabId, url);
  }
}

// Fast LOCAL report — no network. Tech (no CVEs yet) + headers + secrets + recon.
function buildLocalReport(tabId) {
  const data = tabData[tabId] || { tech: [], security: [] };
  const report = {
    url: data.url,
    tech: (data.tech || []).map((t) => ({ ...t, cves: [] })),
    security: data.security || [],
    secrets: data.secrets || [],
    endpoints: data.endpoints || [],
    subdomains: data.subdomains || [],
    params: data.params || [],
    exposures: data.exposures || [],
    activeScan: data.activeScan || [],
    partial: true
  };
  report.risk = computeRisk(report);
  return report;
}

// Build the complete report (tech + CVEs + recon + risk + brain) for a tab.
async function buildFullReport(tabId) {
  const data = tabData[tabId] || { tech: [], security: [] };
  const withCves = await Promise.all(
    (data.tech || []).map(async (t) => {
      try {
        const isScannable = ["web-server", "language", "backend", "frontend", "cms", "js-library"].includes(t.category);
        if (!settings.enableCves || !isScannable) return { ...t, cves: [] };
        const cves = await lookupCVEs(t.tech, t.version, settings.nvdApiKey || null);
        const enriched = await enrichCves(cves);
        return { ...t, cves: enriched };
      } catch (_) {
        return { ...t, cves: [] };
      }
    })
  );
  const report = {
    url: data.url,
    tech: withCves,
    security: data.security || [],
    secrets: data.secrets || [],
    endpoints: data.endpoints || [],
    subdomains: data.subdomains || [],
    params: data.params || [],
    exposures: data.exposures || [],
    activeScan: data.activeScan || []
  };
  report.risk = computeRisk(report);
  try { await runBrain(report); } catch (_) {}
  return report;
}

function shortenUrl(u) {
  try {
    const { pathname, host } = new URL(u);
    return host + pathname.split("/").pop();
  } catch (_) {
    return u;
  }
}

// Update the toolbar badge with the count of security findings + secrets.
function updateBadge(tabId) {
  if (!settings.enableBadge) {
    chrome.action.setBadgeText({ tabId, text: "" });
    return;
  }
  const d = tabData[tabId];
  const count = (d?.security?.length || 0) + (d?.secrets?.length || 0);
  const text = count > 0 ? String(count) : "";
  const hasHigh =
    (d?.security || []).some((f) => f.severity === "HIGH" || f.severity === "CRITICAL") ||
    (d?.secrets || []).some((f) => f.severity === "HIGH" || f.severity === "CRITICAL");
  chrome.action.setBadgeText({ tabId, text });
  chrome.action.setBadgeBackgroundColor({ tabId, color: hasHigh ? "#f85149" : "#d29922" });
}

// 1. Capture response headers (tech fingerprint + security analysis)
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.type !== "main_frame") return;
    const setCookies = [];

    for (const h of details.responseHeaders || []) {
      const name = h.name.toLowerCase();
      const sigs = HEADER_SIGNATURES[name];
      if (sigs) {
        for (const sig of sigs) {
          const m = (h.value || "").match(sig.regex);
          if (m) addTech(details.tabId, { tech: sig.tech, version: m[1] || null, category: sig.category });
        }
      }
      if (name === "set-cookie") {
        setCookies.push(h.value || "");
        for (const c of COOKIE_SIGNATURES) {
          if (c.regex.test(h.value || "")) addTech(details.tabId, { tech: c.tech, version: null, category: c.category });
        }
      }
    }

    // Security findings: missing headers, info leaks, weak cookies, CORS
    const d = ensureTab(details.tabId);
    d.security = settings.enableSecurity
      ? [
          ...analyzeSecurityHeaders(details.responseHeaders || []),
          ...analyzeCookies(setCookies),
          ...analyzeCors(details.responseHeaders || [])
        ].sort((a, b) => (SEVERITY_WEIGHT[b.severity] || 0) - (SEVERITY_WEIGHT[a.severity] || 0))
      : [];

    updateBadge(details.tabId);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders", "extraHeaders"]
);

// Reset tab data on a fresh navigation
chrome.webNavigation?.onBeforeNavigate?.addListener((details) => {
  if (details.frameId === 0) delete tabData[details.tabId];
});

// 2. Receive content-script findings
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  if (msg.type === "RH_FRONTEND" && tabId != null) {
    const d = ensureTab(tabId);
    d.url = msg.url;
    d.scriptUrls = msg.scriptUrls || [];
    (msg.frontend || []).forEach((f) => addTech(tabId, f));

    // Real JS-library detection from actually-loaded script/style URLs.
    scanScriptUrls(msg.scriptUrls || []).forEach((lib) => addTech(tabId, lib));

    // Passive secret scan: inline scripts + visible page text.
    if (settings.enableSecrets !== false) {
      addSecrets(tabId, scanText(msg.inlineCode || "", "inline script", settings.customSecretRules));
      addSecrets(tabId, scanText(msg.bodyText || "", "page HTML", settings.customSecretRules));
      updateBadge(tabId);
      // Deep scan: fetch external JS bundles and scan them (async, non-blocking).
      scanExternalScripts(tabId, msg.scriptUrls, msg.url);
    }
    // Endpoint extraction from inline code (external handled in deep scan).
    addEndpoints(tabId, extractEndpoints(msg.inlineCode || "", "inline script"));
    addRecon(tabId, {
      subdomains: extractSubdomains((msg.inlineCode || "") + " " + (msg.bodyText || ""), baseHostOf(msg.url)),
      params: extractParams(msg.inlineCode || "")
    });

    for (const db of DB_ERROR_SIGNATURES) {
      if (db.regex.test(msg.bodyText || "")) {
        addTech(tabId, { tech: db.tech, version: null, category: db.category });
      }
    }
  }

  // Page-world globals carry real runtime versions (React.version, etc.)
  if (msg.type === "RH_GLOBALS" && tabId != null) {
    mergeGlobals(msg.globals || []).forEach((lib) => addTech(tabId, lib));
  }

  // 3. Popup requests the full report (with CVEs)
  if (msg.type === "RH_GET_REPORT") {
    (async () => {
      const data = tabData[msg.tabId] || { tech: [], security: [] };
      const withCves = await Promise.all(
        data.tech.map(async (t) => ({
          ...t,
          cves: settings.enableCves && ["web-server", "language", "backend", "frontend", "cms", "js-library"].includes(t.category)
            ? await lookupCVEs(t.tech, t.version, settings.nvdApiKey || null)
            : []
        }))
      );
      sendResponse({ url: data.url, tech: withCves, security: data.security || [], secrets: data.secrets || [], endpoints: data.endpoints || [] });
    })();
    return true; // keep channel open for async response
  }

  // 3b. Full report including recon + computed risk score.
  if (msg.type === "RH_GET_FULL") {
    (async () => {
      try {
        await ready;
        sendResponse(await buildFullReport(msg.tabId));
      } catch (err) {
        sendResponse(buildLocalReport(msg.tabId));
      }
    })();
    return true;
  }

  // 3a. Force a fresh scan (called by the popup on open) then return the report.
  if (msg.type === "RH_ENSURE") {
    (async () => {
      try {
        await ready;
        await ensureFreshScan(msg.tabId, msg.url);
        // Return FAST local data (no network) so the UI populates immediately.
        sendResponse(buildLocalReport(msg.tabId));
      } catch (err) {
        sendResponse({ tech: [], security: [], url: msg.url, error: String(err && err.message || err) });
      }
    })();
    return true;
  }

  // 3c. History: save snapshot of current full report.
  if (msg.type === "RH_SAVE_SNAPSHOT") {
    (async () => {
      const report = await buildFullReport(msg.tabId);
      const snap = await saveSnapshot(report);
      sendResponse({ saved: true, snap });
    })();
    return true;
  }

  // 3d. History: list snapshots for a host + diff current vs previous.
  if (msg.type === "RH_GET_HISTORY") {
    (async () => {
      const report = await buildFullReport(msg.tabId);
      const host = (() => { try { return new URL(report.url).host; } catch { return ""; } })();
      const snaps = await listSnapshots(host);
      const current = snapshotOf(report);
      const previous = snaps[0] || null;
      const diff = previous ? diffSnapshots(current, previous) : null;
      sendResponse({ host, current, snapshots: snaps, diff });
    })();
    return true;
  }

  if (msg.type === "RH_CLEAR_HISTORY") {
    (async () => { await clearHistory(); sendResponse({ cleared: true }); })();
    return true;
  }

  // 4. Consent-gated ACTIVE scan: paths + exposures + source maps + GraphQL.
  if (msg.type === "RH_ACTIVE_SCAN") {
    (async () => {
      try {
        const origin = new URL(msg.url).origin;
        const d = ensureTab(msg.tabId);
        const scriptUrls = d.scriptUrls || [];
        const graphqlPaths = (d.endpoints || [])
          .filter((e) => e.type === "graphql")
          .map((e) => { try { return new URL(e.path, origin).pathname; } catch { return null; } })
          .filter(Boolean);

        const [paths, exposures, sourceMaps, graphql] = await Promise.all([
          probePaths(origin),
          checkExposures(origin),
          checkSourceMaps(scriptUrls),
          checkGraphQL(origin, graphqlPaths)
        ]);

        // Safe, non-destructive verification probes (canary reflection + dir listing).
        const [reflections, dirListings] = await Promise.all([
          reflectionProbe(d.url || msg.url, d.params || []),
          directoryListingProbe(origin)
        ]);

        const allExposures = [...exposures, ...sourceMaps, ...graphql, ...reflections, ...dirListings].sort(
          (a, b) => (SEVERITY_WEIGHT[b.severity] || 0) - (SEVERITY_WEIGHT[a.severity] || 0)
        );
        d.activeScan = paths;
        d.exposures = allExposures;
        sendResponse({ origin, findings: paths, exposures: allExposures });
      } catch (err) {
        sendResponse({ error: err.message, findings: [], exposures: [] });
      }
    })();
    return true;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => delete tabData[tabId]);

