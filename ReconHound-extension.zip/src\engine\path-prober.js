// ReconHound — Sensitive path prober (ACTIVE scan)
// Sends real HTTP requests to common sensitive paths and reports which exist.
// This is ACTIVE reconnaissance and only runs after explicit user consent
// confirming the target is authorized for testing.

const PATHS = [
  { path: "/robots.txt", severity: "LOW", note: "Crawler rules; may reveal hidden paths." },
  { path: "/sitemap.xml", severity: "LOW", note: "Site structure disclosure." },
  { path: "/.git/HEAD", severity: "HIGH", note: "Exposed Git repo — source code leak." },
  { path: "/.git/config", severity: "HIGH", note: "Exposed Git config — repo/remote leak." },
  { path: "/.env", severity: "CRITICAL", note: "Environment file — secrets/credentials leak." },
  { path: "/.svn/entries", severity: "HIGH", note: "Exposed SVN metadata." },
  { path: "/.DS_Store", severity: "MEDIUM", note: "Directory listing leak (macOS)." },
  { path: "/config.php.bak", severity: "HIGH", note: "Backup config — possible secrets." },
  { path: "/backup.zip", severity: "HIGH", note: "Exposed backup archive." },
  { path: "/admin", severity: "MEDIUM", note: "Admin interface reachable." },
  { path: "/administrator", severity: "MEDIUM", note: "Admin interface reachable." },
  { path: "/wp-login.php", severity: "LOW", note: "WordPress login present." },
  { path: "/wp-json/wp/v2/users", severity: "MEDIUM", note: "WP REST API user enumeration." },
  { path: "/phpinfo.php", severity: "HIGH", note: "phpinfo() — full PHP config disclosure." },
  { path: "/server-status", severity: "MEDIUM", note: "Apache server-status exposed." },
  { path: "/actuator", severity: "HIGH", note: "Spring Boot Actuator exposed." },
  { path: "/actuator/env", severity: "CRITICAL", note: "Spring env — secrets disclosure." },
  { path: "/swagger-ui.html", severity: "MEDIUM", note: "Swagger UI — API surface disclosure." },
  { path: "/api/swagger.json", severity: "MEDIUM", note: "OpenAPI spec — API surface disclosure." },
  { path: "/.well-known/security.txt", severity: "LOW", note: "Security contact info." }
];

// Probe a single path; treat 200/401/403 as "exists" signals.
async function probe(origin, entry, timeoutMs = 6000) {
  const url = origin.replace(/\/$/, "") + entry.path;
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "GET",
      redirect: "manual",
      credentials: "omit",
      signal: controller.signal
    });
    clearTimeout(t);
    const status = res.status;
    // 404/410 => not present. Others suggest the resource/route exists.
    const exists = ![404, 410].includes(status);
    return exists ? { ...entry, url, status } : null;
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

// Run all probes with limited concurrency to avoid hammering the target.
export async function probePaths(origin, concurrency = 4) {
  const queue = [...PATHS];
  const results = [];

  async function worker() {
    while (queue.length) {
      const entry = queue.shift();
      const hit = await probe(origin, entry);
      if (hit) results.push(hit);
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));
  const weight = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  return results.sort((a, b) => (weight[b.severity] || 0) - (weight[a.severity] || 0));
}

