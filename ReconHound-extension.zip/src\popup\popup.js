// ReconHound — Popup UI controller

let lastReport = null;
let currentTab = null;

// Matrix-rain intro splash — plays briefly on open, then fades out.
function runMatrixSplash() {
  const canvas = document.getElementById("matrix");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const W = (canvas.width = 380);
  const H = (canvas.height = Math.max(380, document.body.scrollHeight || 480));
  const chars = "01░▒▓<>/\\{}[]#$%&*ｱｲｳｴｵｶｷｸ".split("");
  const fontSize = 13;
  const cols = Math.floor(W / fontSize);
  const drops = Array(cols).fill(0).map(() => Math.random() * -20);

  let frames = 0;
  const maxFrames = 60; // ~1.6s at ~37fps
  function draw() {
    ctx.fillStyle = "rgba(5,8,7,0.18)";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#00ff8c";
    ctx.font = fontSize + "px monospace";
    for (let i = 0; i < cols; i++) {
      const ch = chars[(Math.random() * chars.length) | 0];
      const x = i * fontSize;
      const y = drops[i] * fontSize;
      ctx.shadowColor = "#00ff8c";
      ctx.shadowBlur = 6;
      ctx.fillText(ch, x, y);
      if (y > H && Math.random() > 0.975) drops[i] = 0;
      drops[i] += 0.7;
    }
    frames++;
    if (frames < maxFrames) {
      requestAnimationFrame(draw);
    } else {
      canvas.classList.add("fade");
      setTimeout(() => canvas.remove(), 800);
    }
  }
  draw();
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab;
  const stackPanel = document.getElementById("stack");
  const securityPanel = document.getElementById("security");
  const urlEl = document.getElementById("url");
  const secCount = document.getElementById("secCount");

  // Show the target URL immediately, regardless of scan result.
  urlEl.textContent = tab.url || "unknown target";

  // Guard against a restricted page where we can't scan.
  if (/^(chrome|edge|about|chrome-extension|view-source|devtools):/i.test(tab.url || "")) {
    stackPanel.innerHTML = `<p class="empty">// cannot scan browser/system pages — open a normal http(s) site</p>`;
    wireUi(tab);
    return;
  }

  chrome.runtime.sendMessage({ type: "RH_ENSURE", tabId: tab.id, url: tab.url }, (report) => {
    if (chrome.runtime.lastError) {
      stackPanel.innerHTML = `<p class="empty">// engine error: ${chrome.runtime.lastError.message}<br/>try reloading the page</p>`;
      return;
    }
    lastReport = report || { tech: [], security: [] };
    urlEl.textContent = lastReport.url || tab.url;

    renderRisk(lastReport.risk);
    renderBrain(lastReport.brain);

    // Tech stack
    if (!lastReport.tech?.length) {
      stackPanel.innerHTML = `<p class="empty">// no technologies detected — reload target</p>`;
    } else {
      stackPanel.innerHTML = lastReport.tech.map(renderTech).join("");
    }

    // Security findings
    const findings = lastReport.security || [];
    secCount.textContent = String(findings.length);
    securityPanel.innerHTML = findings.length
      ? findings.map(renderFinding).join("")
      : `<p class="empty">// no security findings</p>`;

    // Secret findings
    const secrets = lastReport.secrets || [];
    document.getElementById("secretCount").textContent = String(secrets.length);
    document.getElementById("secrets").innerHTML = secrets.length
      ? secrets.map(renderSecret).join("")
      : `<p class="empty">// no secrets detected in page or scripts</p>`;

    // Extracted endpoints
    const endpoints = lastReport.endpoints || [];
    document.getElementById("endpointCount").textContent = String(endpoints.length);
    document.getElementById("endpoints").innerHTML = endpoints.length
      ? endpoints.map(renderEndpoint).join("")
      : `<p class="empty">// no routes extracted — reload to deep-scan scripts</p>`;

    // Recon: subdomains + params
    renderRecon(lastReport.subdomains || [], lastReport.params || []);

    // Detection is shown instantly above. Now load CVE + exploit-intel in the
    // background (NVD/KEV/EPSS) and refresh the affected panels when ready.
    if (lastReport.partial) {
      document.getElementById("brain").innerHTML = `<p class="empty">// 🧠 analyzing exploit intelligence (NVD · KEV · EPSS)…</p>`;
      loadCveIntel();
    }
  });

  wireUi(tab);
}

// Background load of full CVE + brain data; refreshes stack, brain and risk.
function loadCveIntel() {
  chrome.runtime.sendMessage({ type: "RH_GET_FULL", tabId: currentTab.id }, (full) => {
    if (chrome.runtime.lastError || !full) return;
    lastReport = full;
    renderRisk(full.risk);
    renderBrain(full.brain);
    const stackPanel = document.getElementById("stack");
    if (full.tech?.length) stackPanel.innerHTML = full.tech.map(renderTech).join("");
  });
}

function wireUi(tab) {
  // Tab switching
  document.querySelectorAll(".tab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
      if (btn.dataset.tab === "history") loadHistory();
    });
  });

  document.getElementById("saveSnap").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "RH_SAVE_SNAPSHOT", tabId: currentTab.id }, () => loadHistory());
  });

  // Active-scan consent + run (remembered per host so you confirm only once)
  const authConfirm = document.getElementById("authConfirm");
  const runActive = document.getElementById("runActive");
  const host = (() => { try { return new URL(tab.url).host; } catch { return ""; } })();
  chrome.storage.local.get({ authorizedHosts: [] }, ({ authorizedHosts }) => {
    if (host && authorizedHosts.includes(host)) {
      authConfirm.checked = true;
      runActive.disabled = false;
    }
  });
  authConfirm.addEventListener("change", () => {
    runActive.disabled = !authConfirm.checked;
    if (host) {
      chrome.storage.local.get({ authorizedHosts: [] }, ({ authorizedHosts }) => {
        const set = new Set(authorizedHosts);
        if (authConfirm.checked) set.add(host); else set.delete(host);
        chrome.storage.local.set({ authorizedHosts: [...set] });
      });
    }
  });
  runActive.addEventListener("click", runActiveScan);

  document.getElementById("export").addEventListener("click", exportJson);
  document.getElementById("exportHtml").addEventListener("click", exportHtml);
  document.getElementById("settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
}

function runActiveScan() {
  const runActive = document.getElementById("runActive");
  const out = document.getElementById("activeResults");
  runActive.disabled = true;
  runActive.textContent = "⏳ EXECUTING…";
  out.innerHTML = `<p class="empty">// probing sensitive paths, source maps, graphql…</p>`;

  chrome.runtime.sendMessage(
    { type: "RH_ACTIVE_SCAN", tabId: currentTab.id, url: lastReport?.url || currentTab.url },
    (res) => {
      runActive.disabled = false;
      runActive.textContent = "⚡ EXECUTE ACTIVE SCAN";
      if (chrome.runtime.lastError || res?.error) {
        out.innerHTML = `<p class="empty">${(res && res.error) || chrome.runtime.lastError.message}</p>`;
        return;
      }
      if (lastReport) lastReport.activeScan = res.findings;
      if (lastReport) lastReport.exposures = res.exposures || [];
      const exposures = (res.exposures || []).map(renderExposure).join("");
      const paths = res.findings.length
        ? res.findings.map(renderPathHit).join("")
        : `<p class="empty">// no exposed sensitive paths found</p>`;
      out.innerHTML =
        (exposures ? `<div class="section-label">verified exposures</div>${exposures}` : "") +
        `<div class="section-label">reachable paths</div>${paths}`;
      refreshReport(); // recompute risk grade with new exposures
    }
  );
}

function renderExposure(e) {
  return `
    <div class="finding sev-${e.severity}">
      <div class="finding-title">
        <a href="${e.url}" target="_blank" rel="noreferrer">${escapeHtml(e.title)}</a>
        <span class="badge sev-${e.severity}">${e.severity}</span>
        <span class="conf ${e.needsManual ? "unconfirmed" : "confirmed"}">${e.needsManual ? "verify manually" : "verified"}</span>
      </div>
      <div class="finding-detail">${escapeHtml(e.detail)}</div>
    </div>`;
}

function renderSecret(s) {
  return `
    <div class="finding sev-${s.severity}">
      <div class="finding-title">${escapeHtml(s.title)}<span class="badge sev-${s.severity}">${s.severity}</span></div>
      <div class="finding-detail">
        <code>${escapeHtml(s.match)}</code><br/>
        <span class="muted">source: ${escapeHtml(s.source)} · entropy ${s.entropy}</span>
      </div>
    </div>`;
}

function renderEndpoint(e) {
  return `
    <div class="endpoint">
      <span class="etype ${e.type}">${e.type}</span>
      <a href="${escapeHtml(e.path)}" target="_blank" rel="noreferrer">${escapeHtml(e.path)}</a>
      <div class="muted">${escapeHtml(e.source)}</div>
    </div>`;
}

function renderPathHit(h) {
  return `
    <div class="finding sev-${h.severity}">
      <div class="finding-title">
        <a href="${h.url}" target="_blank" rel="noreferrer">${escapeHtml(h.path)}</a>
        <span class="badge sev-${h.severity}">${h.severity}</span>
        <span class="conf">HTTP ${h.status}</span>
      </div>
      <div class="finding-detail">${escapeHtml(h.note)}</div>
    </div>`;
}

function renderTech(t) {
  const cves = (t.cves || []).slice(0, 6).map((c) => {
    const tags = [];
    if (c.ransomware) tags.push(`<span class="xtag rw">☣ RANSOMWARE</span>`);
    if (c.kev) tags.push(`<span class="xtag kev">⚡ ACTIVELY EXPLOITED</span>`);
    else if (c.exploitAvailable) tags.push(`<span class="xtag exp">⚑ EXPLOIT LIKELY</span>`);

    const links = [
      `<a href="${c.exploitDb}" target="_blank" rel="noreferrer">ExploitDB</a>`,
      `<a href="${c.metasploit}" target="_blank" rel="noreferrer">Metasploit</a>`,
      `<a href="${c.nuclei}" target="_blank" rel="noreferrer">Nuclei</a>`,
      `<a href="${c.githubPoc}" target="_blank" rel="noreferrer">PoC</a>`
    ].join(" · ");

    return `
      <div class="cve ${c.kev ? "kev-row" : ""}">
        <a href="${c.nvd}" target="_blank" rel="noreferrer">${c.id}</a>
        <span class="sev-${c.severity}">${c.severity}${c.score != null ? " (" + c.score + ")" : ""}</span>
        ${c.confidence ? `<span class="conf ${c.confidence}">${c.confidence}</span>` : ""}
        ${tags.join(" ")}
        <div class="xlinks">${links}</div>
      </div>`;
  }).join("");

  return `
    <div class="tech">
      <div class="tech-name">${escapeHtml(t.tech)}${t.version ? ` <span class="ver">v${escapeHtml(t.version)}</span>` : ""}</div>
      <div class="cat">${escapeHtml(t.category)}</div>
      ${cves}
    </div>`;
}

function renderFinding(f) {
  return `
    <div class="finding sev-${f.severity}">
      <div class="finding-title">${escapeHtml(f.title)}<span class="badge sev-${f.severity}">${f.severity}</span></div>
      <div class="finding-detail">${escapeHtml(f.detail)}</div>
    </div>`;
}

function renderRisk(risk) {
  if (!risk) return;
  const gradeEl = document.getElementById("grade");
  const cls = "g-" + (risk.grade === "A+" ? "Aplus" : risk.grade);
  gradeEl.className = "grade " + cls;
  gradeEl.textContent = risk.grade;

  document.getElementById("scoreVal").textContent = `${risk.score}/100`;
  document.getElementById("barFill").style.width = risk.score + "%";

  const c = risk.counts || {};
  document.getElementById("sevLegend").innerHTML =
    `<span class="lg-c">C:<b>${c.CRITICAL || 0}</b></span>
     <span class="lg-h">H:<b>${c.HIGH || 0}</b></span>
     <span class="lg-m">M:<b>${c.MEDIUM || 0}</b></span>
     <span class="lg-l">L:<b>${c.LOW || 0}</b></span>`;
}

function renderBrain(brain) {
  const panel = document.getElementById("brain");
  if (!panel) return;
  if (!brain || !brain.top) {
    panel.innerHTML = `<p class="empty">// no exploit-intelligence data — reload target</p>`;
    return;
  }
  const cls = brain.counts.weaponized ? "weaponized" : brain.counts.likely ? "likely" : "low";
  const head = `
    <div class="brain-head ${cls}">
      <div class="brain-meter">
        <div class="brain-score">${brain.overall}</div>
        <div class="brain-score-l">EXPLOITABILITY</div>
      </div>
      <div class="brain-headline">${escapeHtml(brain.headline)}</div>
    </div>
    <div class="brain-stats">
      <span class="vbadge weaponized">${brain.counts.weaponized} WEAPONIZED</span>
      <span class="vbadge likely">${brain.counts.likely} LIKELY</span>
      <span class="muted">${brain.counts.total} CVE(s) analyzed · NVD + KEV + EPSS</span>
    </div>`;

  const rows = brain.top.length
    ? brain.top.map(renderBrainRow).join("")
    : `<p class="empty">// no CVEs correlated to detected stack</p>`;

  panel.innerHTML = head + `<div class="section-label">prioritized exploit targets</div>` + rows;
}

function renderBrainRow(r) {
  const epssPct = r.epss != null ? (r.epss * 100).toFixed(1) + "%" : "—";
  const tags = [];
  if (r.ransomware) tags.push(`<span class="xtag rw">☣ RANSOMWARE</span>`);
  if (r.kev) tags.push(`<span class="xtag kev">⚡ KEV</span>`);
  return `
    <div class="brain-row v-${r.verdictClass}">
      <div class="brain-row-top">
        <a href="${r.nvd}" target="_blank" rel="noreferrer">${escapeHtml(r.id)}</a>
        <span class="vbadge ${r.verdictClass}">${r.verdict}</span>
        <span class="brain-exp">${r.exploitability}</span>
      </div>
      <div class="muted">${escapeHtml(r.tech)} · ${r.severity}${r.score != null ? " (" + r.score + ")" : ""} · EPSS ${epssPct} ${tags.join(" ")}</div>
      <div class="brain-reason">${escapeHtml(r.reasoning)}</div>
      <div class="brain-action">▸ ${escapeHtml(r.action)}</div>
      <div class="xlinks">
        <a href="${r.metasploit}" target="_blank" rel="noreferrer">Metasploit</a> ·
        <a href="${r.nuclei}" target="_blank" rel="noreferrer">Nuclei</a> ·
        <a href="${r.exploitDb}" target="_blank" rel="noreferrer">ExploitDB</a> ·
        <a href="${r.githubPoc}" target="_blank" rel="noreferrer">PoC</a>
      </div>
    </div>`;
}

function renderRecon(subdomains, params) {
  const total = subdomains.length + params.length;
  document.getElementById("reconCount").textContent = String(total);
  const panel = document.getElementById("recon");
  if (!total) {
    panel.innerHTML = `<p class="empty">// no subdomains or params extracted yet</p>`;
    return;
  }
  const subChips = subdomains.map((s) => `<span class="chip">${escapeHtml(s)}</span>`).join("");
  const paramChips = params.map((p) => `<span class="chip">${escapeHtml(p)}</span>`).join("");
  panel.innerHTML =
    `<div class="section-label">subdomains (${subdomains.length})</div>` +
    (subChips ? `<div class="chips">${subChips}</div>` : `<p class="muted">none</p>`) +
    `<div class="section-label">query params (${params.length})</div>` +
    (paramChips ? `<div class="chips">${paramChips}</div>` : `<p class="muted">none</p>`);
}

function refreshReport() {
  chrome.runtime.sendMessage({ type: "RH_GET_FULL", tabId: currentTab.id }, (report) => {
    if (chrome.runtime.lastError || !report) return;
    lastReport = report;
    renderRisk(report.risk);
  });
}

function loadHistory() {
  const diffBox = document.getElementById("diffBox");
  const list = document.getElementById("historyList");
  chrome.runtime.sendMessage({ type: "RH_GET_HISTORY", tabId: currentTab.id }, (res) => {
    if (chrome.runtime.lastError || !res) {
      list.innerHTML = `<p class="empty">// history unavailable</p>`;
      return;
    }
    // Diff vs most recent saved snapshot
    if (res.diff) {
      const d = res.diff;
      const deltaCls = d.scoreDelta > 0 ? "delta-up" : d.scoreDelta < 0 ? "delta-down" : "delta-flat";
      const deltaTxt = (d.scoreDelta > 0 ? "+" : "") + d.scoreDelta;
      const added = d.added.slice(0, 30).map((x) => `<div class="diff-item add">${escapeHtml(x)}</div>`).join("");
      const removed = d.removed.slice(0, 30).map((x) => `<div class="diff-item rem">${escapeHtml(x)}</div>`).join("");
      diffBox.innerHTML = `
        <div class="diff">
          <div class="diff-head">DIFF vs last snapshot — grade ${escapeHtml(d.gradeFrom)} → ${escapeHtml(d.gradeTo)}
            · score <span class="${deltaCls}">${deltaTxt}</span></div>
          ${added || removed
            ? added + removed
            : `<div class="diff-item">// no changes since last snapshot</div>`}
        </div>`;
    } else {
      diffBox.innerHTML = `<p class="muted">// no prior snapshot for ${escapeHtml(res.host)} — save one to start tracking</p>`;
    }

    // History list for this host
    list.innerHTML = res.snapshots.length
      ? res.snapshots.map(renderSnap).join("")
      : `<p class="empty">// no saved snapshots</p>`;
  });
}

function renderSnap(s) {
  const cls = "g-" + (s.grade === "A+" ? "Aplus" : s.grade);
  const when = new Date(s.ts).toLocaleString();
  const c = s.counts || {};
  return `
    <div class="snap-row">
      <span class="snap-grade grade ${cls}">${escapeHtml(s.grade)}</span>
      <div style="flex:1;margin:0 10px">
        <div>${s.score}/100 · C:${c.CRITICAL || 0} H:${c.HIGH || 0} M:${c.MEDIUM || 0} L:${c.LOW || 0}</div>
        <div class="snap-meta">${escapeHtml(when)}</div>
      </div>
    </div>`;
}

function exportJson() {
  if (!lastReport) return;
  download(
    new Blob([JSON.stringify(lastReport, null, 2)], { type: "application/json" }),
    `reconhound-report-${Date.now()}.json`
  );
}

function exportHtml() {
  if (!lastReport) return;
  const r = lastReport;
  const risk = r.risk || { grade: "—", score: 0, counts: {} };
  const c = risk.counts || {};
  const now = new Date();
  const reportId = "RH-" + now.getTime().toString(36).toUpperCase();

  const sevTag = (s) => `<span class="sev sev-${s}">${s}</span>`;

  const techRows = (r.tech || []).map((t) => {
    const cves = (t.cves || []).map((c2) => {
      const flags = [];
      if (c2.ransomware) flags.push('<b style="color:#c0392b">RANSOMWARE</b>');
      if (c2.kev) flags.push('<b style="color:#b1006b">KEV / ACTIVELY EXPLOITED</b>');
      else if (c2.exploitAvailable) flags.push('<span style="color:#b8860b">exploit likely</span>');
      const links = [
        `<a href="${c2.exploitDb}">ExploitDB</a>`,
        `<a href="${c2.metasploit}">Metasploit</a>`,
        `<a href="${c2.nuclei}">Nuclei</a>`,
        `<a href="${c2.githubPoc}">PoC</a>`
      ].join(" · ");
      return `<li><a href="${c2.nvd}">${esc(c2.id)}</a> ${sevTag(c2.severity)}${c2.score != null ? " " + c2.score : ""}
        ${c2.confidence ? `<em>${esc(c2.confidence)}</em>` : ""} ${flags.join(" ")}<br><small>${links}</small></li>`;
    }).join("");
    return `<tr><td>${esc(t.tech)}</td><td>${esc(t.version || "—")}</td><td>${esc(t.category)}</td>
            <td>${cves ? `<ul>${cves}</ul>` : "—"}</td></tr>`;
  }).join("");

  const findingRows = (arr, cols) => (arr || []).map(cols).join("");

  const secRows = findingRows(r.security, (f) =>
    `<tr><td>${sevTag(f.severity)}</td><td>${esc(f.title)}</td><td>${esc(f.detail)}</td></tr>`);
  const secretRows = findingRows(r.secrets, (s) =>
    `<tr><td>${sevTag(s.severity)}</td><td>${esc(s.title)}</td><td><code>${esc(s.match)}</code></td><td>${esc(s.source)}</td></tr>`);
  const exposureRows = findingRows(r.exposures, (e) =>
    `<tr><td>${sevTag(e.severity)}</td><td><a href="${e.url}">${esc(e.title)}</a></td><td>${esc(e.detail)}</td></tr>`);
  const endpointRows = findingRows(r.endpoints, (e) =>
    `<tr><td>${esc(e.type)}</td><td><a href="${esc(e.path)}">${esc(e.path)}</a></td><td>${esc(e.source)}</td></tr>`);
  const activeRows = findingRows(r.activeScan, (h) =>
    `<tr><td>${sevTag(h.severity)}</td><td><a href="${h.url}">${esc(h.path)}</a></td><td>HTTP ${h.status}</td><td>${esc(h.note)}</td></tr>`);

  const subChips = (r.subdomains || []).map((s) => `<span class="chip">${esc(s)}</span>`).join("") || "—";
  const paramChips = (r.params || []).map((p) => `<span class="chip">${esc(p)}</span>`).join("") || "—";

  const total = risk.total || 0;
  const summary = buildExecSummary(risk, r);
  const brainBlock = buildBrainBlock(r.brain);

  const html = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>ReconHound Assessment Report — ${esc(r.url || "")}</title>
<style>
  :root{--crit:#c0392b;--high:#e67e22;--med:#d4a017;--low:#27ae60;--ink:#1a2027;--soft:#5b6770;--line:#e4e8ec;--bg:#f5f7f9;}
  *{box-sizing:border-box}
  body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;color:var(--ink);background:var(--bg);font-size:14px;line-height:1.55}
  .page{max-width:900px;margin:0 auto;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .cover{background:linear-gradient(135deg,#0b1f17,#10362a);color:#eafff5;padding:40px}
  .cover h1{margin:0;font-size:30px;letter-spacing:1px}
  .cover .sub{color:#7fdcb4;margin-top:4px;font-size:13px}
  .cover .target{margin-top:20px;font-size:16px;word-break:break-all}
  .meta-grid{display:flex;gap:30px;flex-wrap:wrap;margin-top:18px;font-size:12px;color:#b9e8d4}
  .meta-grid b{display:block;color:#eafff5;font-size:13px}
  .gradewrap{display:flex;align-items:center;gap:24px;margin-top:24px}
  .gradebig{font-size:64px;font-weight:800;line-height:1;padding:8px 22px;border-radius:12px;background:rgba(255,255,255,.08)}
  .g-A,.g-Aplus{color:#3ddc84}.g-B{color:#48d1ff}.g-C{color:#ffcf3a}.g-D{color:#ff9a3a}.g-F{color:#ff5a5a}
  .scoreline{font-size:13px;color:#b9e8d4}
  .scorebar{height:10px;width:280px;background:rgba(255,255,255,.12);border-radius:6px;overflow:hidden;margin-top:6px}
  .scorebar > i{display:block;height:100%;background:linear-gradient(90deg,#3ddc84,#ffcf3a 60%,#ff5a5a)}
  section{padding:26px 40px;border-top:1px solid var(--line)}
  h2{font-size:18px;margin:0 0 14px;padding-bottom:8px;border-bottom:2px solid var(--ink)}
  h3{font-size:14px;margin:18px 0 8px;color:var(--soft);text-transform:uppercase;letter-spacing:.5px}
  p{margin:8px 0}
  table{border-collapse:collapse;width:100%;margin-top:8px;font-size:13px}
  th,td{border:1px solid var(--line);padding:7px 9px;text-align:left;vertical-align:top}
  th{background:var(--bg);font-size:12px;text-transform:uppercase;letter-spacing:.4px;color:var(--soft)}
  ul{margin:0;padding-left:18px}
  code{background:#f0f2f4;border:1px solid var(--line);border-radius:3px;padding:1px 5px;font-size:12px;word-break:break-all}
  .sev{font-weight:700;font-size:11px;padding:2px 8px;border-radius:10px;color:#fff;display:inline-block;text-transform:uppercase}
  .sev-CRITICAL{background:var(--crit)}.sev-HIGH{background:var(--high)}.sev-MEDIUM{background:var(--med)}.sev-LOW{background:var(--low)}.sev-UNKNOWN{background:#90a0ab}
  .cards{display:flex;gap:12px;flex-wrap:wrap;margin:10px 0}
  .card{flex:1;min-width:120px;border:1px solid var(--line);border-radius:8px;padding:12px;text-align:center}
  .card .n{font-size:28px;font-weight:800}
  .card.crit .n{color:var(--crit)}.card.high .n{color:var(--high)}.card.med .n{color:var(--med)}.card.low .n{color:var(--low)}
  .card .l{font-size:11px;color:var(--soft);text-transform:uppercase;letter-spacing:.5px}
  .chip{display:inline-block;background:#eef4f1;border:1px solid var(--line);border-radius:4px;padding:2px 7px;margin:2px;font-size:12px;font-family:monospace}
  .callout{background:#fff8e6;border-left:4px solid var(--med);padding:12px 14px;border-radius:0 6px 6px 0;font-size:13px}
  .disclaimer{background:#fbecec;border-left:4px solid var(--crit);padding:12px 14px;border-radius:0 6px 6px 0;font-size:12px;color:#7a2b2b}
  footer{padding:18px 40px;font-size:11px;color:var(--soft);text-align:center;border-top:1px solid var(--line)}
  /* Floating report toolbar */
  .rh-toolbar{position:fixed;top:14px;right:14px;display:flex;gap:8px;z-index:10}
  .rh-toolbar button{font-family:inherit;font-size:12px;padding:7px 12px;border-radius:6px;border:1px solid var(--line);background:#fff;color:var(--ink);cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.12)}
  .rh-toolbar button:hover{background:var(--bg)}
  /* Dark theme overrides */
  body.dark{--ink:#cfe9dd;--soft:#7fa493;--line:#1e3a2c;--bg:#0a0f0c}
  body.dark .page{background:#0c130f}
  body.dark .rh-toolbar button{background:#0c130f;color:#cfe9dd;border-color:#1e3a2c}
  body.dark th{background:#0a0f0c}
  body.dark code{background:#0a1810;border-color:#1e3a2c;color:#ffb000}
  body.dark .callout{background:#1c1604;border-color:#d4a017}
  body.dark .disclaimer{background:#1c0c0c;border-color:#c0392b;color:#ff9d9d}
  body.dark .chip{background:#0a1810;border-color:#1e3a2c}
  @media print{body{background:#fff}.page{box-shadow:none}.rh-toolbar{display:none}body.dark{--ink:#1a2027;--soft:#5b6770;--line:#e4e8ec;--bg:#f5f7f9}body.dark .page{background:#fff}}
</style></head><body><div class="page">

  <div class="rh-toolbar">
    <button onclick="document.body.classList.toggle('dark')">🌓 Dark / Light</button>
    <button onclick="window.print()">🖨 Print / PDF</button>
  </div>

  <div class="cover">
    <h1>🛡 SECURITY ASSESSMENT REPORT</h1>
    <div class="sub">ReconHound · Automated Reconnaissance & Vulnerability Assessment</div>
    <div class="target"><b>Target:</b> ${esc(r.url || "n/a")}</div>
    <div class="meta-grid">
      <div><b>${esc(reportId)}</b>Report ID</div>
      <div><b>${now.toLocaleString()}</b>Generated</div>
      <div><b>${total}</b>Total Findings</div>
      <div><b>${(r.tech || []).length}</b>Technologies</div>
    </div>
    <div class="gradewrap">
      <div class="gradebig ${risk.grade === "A+" ? "g-Aplus" : "g-" + risk.grade}">${esc(risk.grade)}</div>
      <div>
        <div class="scoreline">Overall Risk Score: <b>${risk.score}/100</b></div>
        <div class="scorebar"><i style="width:${risk.score}%"></i></div>
        <div class="scoreline" style="margin-top:8px">
          ${sevTag("CRITICAL")} ${c.CRITICAL || 0} &nbsp; ${sevTag("HIGH")} ${c.HIGH || 0} &nbsp;
          ${sevTag("MEDIUM")} ${c.MEDIUM || 0} &nbsp; ${sevTag("LOW")} ${c.LOW || 0}
        </div>
      </div>
    </div>
  </div>

  <section>
    <h2>1. Executive Summary</h2>
    ${summary}
    <div class="cards">
      <div class="card crit"><div class="n">${c.CRITICAL || 0}</div><div class="l">Critical</div></div>
      <div class="card high"><div class="n">${c.HIGH || 0}</div><div class="l">High</div></div>
      <div class="card med"><div class="n">${c.MEDIUM || 0}</div><div class="l">Medium</div></div>
      <div class="card low"><div class="n">${c.LOW || 0}</div><div class="l">Low</div></div>
    </div>
  </section>

  <section>
    <h2>2. Exploit Intelligence (AI Brain)</h2>
    ${brainBlock}
  </section>

  <section>
    <h2>3. Methodology & Scope</h2>
    <p>This assessment was produced by the ReconHound browser extension using a
    combination of <b>passive fingerprinting</b> (HTTP response headers, loaded
    resources, runtime globals) and, where explicitly authorized, <b>active
    probing</b> (sensitive-path discovery, VCS/secret-file exposure verification,
    source-map and GraphQL introspection checks). CVE correlation is performed
    against the NIST NVD database with CPE version-range matching. Findings marked
    <em>confirmed</em> were validated against the detected version; <em>unconfirmed</em>
    are name-only matches requiring manual verification.</p>
    <div class="callout">Severity ratings follow CVSS-aligned bands
    (Critical ≥ 9.0, High 7.0–8.9, Medium 4.0–6.9, Low &lt; 4.0). The overall grade
    is a weighted aggregate; any Critical finding caps the grade at <b>F</b>.</div>
  </section>

  <section>
    <h2>4. Technology Stack & Known Vulnerabilities</h2>
    <table><thead><tr><th>Technology</th><th>Version</th><th>Category</th><th>CVEs</th></tr></thead>
    <tbody>${techRows || "<tr><td colspan=4>None detected</td></tr>"}</tbody></table>
  </section>

  <section>
    <h2>5. Security Misconfigurations</h2>
    <table><thead><tr><th>Severity</th><th>Issue</th><th>Detail</th></tr></thead>
    <tbody>${secRows || "<tr><td colspan=3>None identified</td></tr>"}</tbody></table>
  </section>

  <section>
    <h2>6. Credential & Secret Exposure</h2>
    <table><thead><tr><th>Severity</th><th>Type</th><th>Match (redacted)</th><th>Source</th></tr></thead>
    <tbody>${secretRows || "<tr><td colspan=4>None identified</td></tr>"}</tbody></table>
  </section>

  <section>
    <h2>7. Verified Exposures (Active)</h2>
    <table><thead><tr><th>Severity</th><th>Exposure</th><th>Detail</th></tr></thead>
    <tbody>${exposureRows || "<tr><td colspan=3>Active scan not run / none verified</td></tr>"}</tbody></table>
    <h3>Reachable Sensitive Paths</h3>
    <table><thead><tr><th>Severity</th><th>Path</th><th>Status</th><th>Note</th></tr></thead>
    <tbody>${activeRows || "<tr><td colspan=4>Active scan not run</td></tr>"}</tbody></table>
  </section>

  <section>
    <h2>8. Attack Surface — Endpoints & Recon</h2>
    <table><thead><tr><th>Type</th><th>Path / URL</th><th>Source</th></tr></thead>
    <tbody>${endpointRows || "<tr><td colspan=3>None extracted</td></tr>"}</tbody></table>
    <h3>Discovered Subdomains</h3><p>${subChips}</p>
    <h3>Observed Query Parameters</h3><p>${paramChips}</p>
  </section>

  <section>
    <h2>9. Recommendations</h2>
    <ol>
      ${buildRecommendations(r)}
    </ol>
  </section>

  <footer>
    <div class="disclaimer"><b>Legal Disclaimer:</b> This report is intended solely
    for authorized security assessment of systems you own or have explicit written
    permission to test. Unauthorized use may violate computer-misuse laws.
    ReconHound and its authors accept no liability for misuse.</div>
    <p style="margin-top:12px">Generated by ReconHound · Report ${esc(reportId)} · ${now.toISOString()}</p>
  </footer>

</div></body></html>`;

  download(new Blob([html], { type: "text/html" }), `ReconHound_Report_${reportId}.html`);
}

function buildBrainBlock(brain) {
  if (!brain || !brain.top || !brain.top.length) {
    return `<p>No CVEs were correlated to the detected stack, so no exploit-intelligence
      ranking is available. Manual testing is still recommended.</p>`;
  }
  const rows = brain.top.map((r) => {
    const epss = r.epss != null ? (r.epss * 100).toFixed(1) + "%" : "—";
    const flags = [];
    if (r.ransomware) flags.push('<b style="color:#c0392b">RANSOMWARE</b>');
    if (r.kev) flags.push('<b style="color:#b1006b">KEV</b>');
    const links = `<a href="${r.metasploit}">Metasploit</a> · <a href="${r.nuclei}">Nuclei</a> · <a href="${r.exploitDb}">ExploitDB</a> · <a href="${r.githubPoc}">PoC</a>`;
    return `<tr>
      <td><b>${esc(String(r.exploitability))}</b></td>
      <td>${esc(r.verdict)}</td>
      <td><a href="${r.nvd}">${esc(r.id)}</a> ${flags.join(" ")}</td>
      <td>${esc(r.tech)}</td>
      <td>${esc(epss)}</td>
      <td>${esc(r.reasoning)}<br><small>▸ ${esc(r.action)}</small><br><small>${links}</small></td>
    </tr>`;
  }).join("");

  return `
    <p><b>${esc(brain.headline)}</b></p>
    <p>Overall exploitability index: <b>${brain.overall}/100</b> · Weaponized: <b>${brain.counts.weaponized}</b>
       · Likely exploitable: <b>${brain.counts.likely}</b> · CVEs analyzed: ${brain.counts.total}.
       Scoring fuses NVD severity, CISA KEV (active exploitation), EPSS (exploitation probability)
       and public exploit-tool availability.</p>
    <table><thead><tr><th>Exploit&nbsp;Idx</th><th>Verdict</th><th>CVE</th><th>Component</th><th>EPSS</th><th>Reasoning &amp; Action</th></tr></thead>
    <tbody>${rows}</tbody></table>`;
}

function buildExecSummary(risk, r) {
  const c = risk.counts || {};
  const grade = risk.grade;
  let posture;
  if (grade === "F") posture = "a <b>critical</b> security posture requiring immediate remediation";
  else if (grade === "D") posture = "a <b>poor</b> security posture with serious weaknesses";
  else if (grade === "C") posture = "a <b>moderate</b> security posture with notable gaps";
  else if (grade === "B") posture = "a <b>fair</b> security posture with minor issues";
  else posture = "a <b>strong</b> security posture";

  const highlights = [];
  if ((r.secrets || []).length) highlights.push(`${r.secrets.length} potential credential/secret leak(s)`);
  if ((r.exposures || []).length) highlights.push(`${r.exposures.length} verified file/VCS exposure(s)`);
  const cveCount = (r.tech || []).reduce((n, t) => n + (t.cves || []).length, 0);
  if (cveCount) highlights.push(`${cveCount} known CVE(s) across the stack`);
  const kevCount = (r.tech || []).reduce((n, t) => n + (t.cves || []).filter((c) => c.kev).length, 0);
  if (kevCount) highlights.push(`<b style="color:#b1006b">${kevCount} actively-exploited (CISA KEV) CVE(s)</b>`);
  if (c.CRITICAL) highlights.push(`${c.CRITICAL} critical-severity issue(s)`);

  const list = highlights.length
    ? `Key concerns include ${highlights.join(", ")}.`
    : "No high-impact issues were automatically identified, though manual testing is still recommended.";

  return `<p>The target <code>${esc(r.url || "")}</code> was assessed and assigned an
    overall risk grade of <b>${esc(grade)}</b> (score ${risk.score}/100), indicating
    ${posture}. ${list}</p>`;
}

function buildRecommendations(r) {
  const recs = [];
  if ((r.security || []).some((f) => /content-security-policy/i.test(f.title)))
    recs.push("Implement a strict Content-Security-Policy to mitigate XSS.");
  if ((r.security || []).some((f) => /hsts|strict-transport/i.test(f.title)))
    recs.push("Enable HTTP Strict Transport Security (HSTS) with a long max-age.");
  if ((r.secrets || []).length)
    recs.push("Rotate any exposed credentials immediately and remove secrets from client-side code.");
  if ((r.exposures || []).length)
    recs.push("Block public access to VCS metadata (.git/.svn), .env and backup files at the web-server level.");
  if ((r.tech || []).some((t) => (t.cves || []).length))
    recs.push("Upgrade outdated components to patched versions to remediate known CVEs.");
  if ((r.security || []).some((f) => /cors/i.test(f.title)))
    recs.push("Tighten CORS policy — avoid wildcard origins combined with credentials.");
  if (!recs.length)
    recs.push("Maintain current controls and schedule periodic re-assessment.");
  recs.push("Conduct manual penetration testing to validate and expand on these automated findings.");
  return recs.map((x) => `<li>${esc(x)}</li>`).join("");
}

function download(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

try { runMatrixSplash(); } catch (_) {}
init().catch((e) => {
  const s = document.getElementById("stack");
  if (s) s.innerHTML = `<p class="empty">// init error: ${String(e && e.message || e)}</p>`;
});

