m// ReconHound — Safe verification checks (ACTIVE, non-destructive)
// These confirm whether a weakness is likely PRESENT using benign canary values
// and signature checks — NOT weaponized payloads. They never attempt to execute
// code, modify data, or cause harm. Results flag surfaces for MANUAL confirmation.

// Unique, harmless canary token (no HTML/script — just a marker string).
function canary() {
  return "RHCANARY" + Math.random().toString(36).slice(2, 10).toUpperCase();
}

async function getText(url, timeoutMs = 6000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method: "GET", credentials: "omit", redirect: "follow", signal: controller.signal });
    clearTimeout(t);
    const text = (await res.text()).slice(0, 200000);
    return { status: res.status, text, ctype: res.headers.get("content-type") || "" };
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

// Reflected-parameter probe: substitute a benign canary into each query param and
// check whether it is echoed back UN-encoded in an HTML response — a strong
// indicator of a reflected-XSS surface that warrants manual testing.
export async function reflectionProbe(pageUrl, params = [], maxParams = 12) {
  let base;
  try { base = new URL(pageUrl); } catch (_) { return []; }
  if (!/^https?:$/.test(base.protocol)) return [];

  // Candidate params: those already on the URL + discovered ones.
  const candidate = new Set();
  base.searchParams.forEach((_, k) => candidate.add(k));
  params.forEach((p) => candidate.add(p));
  const list = [...candidate].slice(0, maxParams);
  if (!list.length) return [];

  const findings = [];
  const queue = [...list];

  async function worker() {
    while (queue.length) {
      const param = queue.shift();
      const mark = canary();
      const u = new URL(base.toString());
      u.searchParams.set(param, mark);
      const res = await getText(u.toString());
      if (!res || !/html/i.test(res.ctype)) continue;
      if (res.text.includes(mark)) {
        // Reflected. Check if it lands in a raw (un-encoded) HTML context.
        const encoded = res.text.includes(mark.replace(/</g, "&lt;")); // canary has no <, always false-ish
        findings.push({
          id: "reflected-param",
          title: `Reflected input in parameter "${param}"`,
          severity: "MEDIUM",
          url: u.toString(),
          detail: "User-controlled value is echoed into the HTML response. Manually verify output encoding to confirm/deny reflected XSS.",
          verified: true,
          needsManual: true
        });
      }
    }
  }

  await Promise.all(Array.from({ length: 4 }, worker));
  return findings;
}

// Directory-listing probe: confirms an open directory index (safe GET).
export async function directoryListingProbe(origin, paths = ["/uploads/", "/images/", "/files/", "/assets/", "/backup/"]) {
  const base = origin.replace(/\/$/, "");
  const findings = [];
  await Promise.all(
    paths.map(async (p) => {
      const url = base + p;
      const res = await getText(url);
      if (res && res.status < 400 && /<title>\s*Index of\s*\/|Directory listing for/i.test(res.text)) {
        findings.push({
          id: "dir-listing",
          title: `Open directory listing at ${p}`,
          severity: "MEDIUM",
          url,
          detail: "Server returns a browsable directory index — may expose files not meant to be public.",
          verified: true
        });
      }
    })
  );
  return findings;
}

