// ReconHound — Scan history & diff
// Persists compact scan snapshots in chrome.storage.local and computes diffs
// between scans of the same target for change tracking across engagements.

const KEY = "rh_history";
const MAX = 60; // cap stored snapshots

// Build a stable signature for a finding so diffs are reliable across scans.
function sig(kind, f) {
  switch (kind) {
    case "tech": return `tech:${f.tech}@${f.version || "?"}`;
    case "cve": return `cve:${f.id}`;
    case "security": return `sec:${f.title}`;
    case "secret": return `key:${f.id}:${f.match}`;
    case "exposure": return `exp:${f.id || f.title}`;
    case "endpoint": return `ep:${f.path}`;
    default: return `${kind}:${JSON.stringify(f)}`;
  }
}

// Reduce a full report to a compact, diff-able snapshot.
export function snapshotOf(report) {
  const sigs = [];
  (report.tech || []).forEach((t) => {
    sigs.push(sig("tech", t));
    (t.cves || []).forEach((c) => sigs.push(sig("cve", c)));
  });
  (report.security || []).forEach((f) => sigs.push(sig("security", f)));
  (report.secrets || []).forEach((f) => sigs.push(sig("secret", f)));
  (report.exposures || []).forEach((f) => sigs.push(sig("exposure", f)));
  (report.endpoints || []).forEach((f) => sigs.push(sig("endpoint", f)));

  return {
    id: "snap-" + Date.now().toString(36),
    url: report.url || "",
    host: hostOf(report.url),
    ts: Date.now(),
    grade: report.risk?.grade ?? "—",
    score: report.risk?.score ?? 0,
    counts: report.risk?.counts ?? {},
    sigs,
    labels: buildLabels(report)
  };
}

// Human-readable labels keyed by signature, for nicer diff output.
function buildLabels(report) {
  const labels = {};
  (report.tech || []).forEach((t) => {
    labels[sig("tech", t)] = `${t.tech} ${t.version || ""}`.trim();
    (t.cves || []).forEach((c) => (labels[sig("cve", c)] = `${c.id} (${c.severity})`));
  });
  (report.security || []).forEach((f) => (labels[sig("security", f)] = f.title));
  (report.secrets || []).forEach((f) => (labels[sig("secret", f)] = f.title + " " + f.match));
  (report.exposures || []).forEach((f) => (labels[sig("exposure", f)] = f.title));
  (report.endpoints || []).forEach((f) => (labels[sig("endpoint", f)] = f.path));
  return labels;
}

function hostOf(url) {
  try { return new URL(url).host; } catch (_) { return ""; }
}

export async function saveSnapshot(report) {
  const snap = snapshotOf(report);
  const all = await listSnapshots();
  all.unshift(snap);
  const trimmed = all.slice(0, MAX);
  await chrome.storage.local.set({ [KEY]: trimmed });
  return snap;
}

export async function listSnapshots(host = null) {
  const data = await chrome.storage.local.get(KEY);
  const all = data[KEY] || [];
  return host ? all.filter((s) => s.host === host) : all;
}

export async function clearHistory() {
  await chrome.storage.local.set({ [KEY]: [] });
}

// Diff two snapshots (current vs previous) → added / removed labelled items.
export function diffSnapshots(current, previous) {
  const curSet = new Set(current.sigs);
  const prevSet = new Set(previous.sigs);
  const labels = { ...previous.labels, ...current.labels };

  const added = [...curSet].filter((s) => !prevSet.has(s)).map((s) => labels[s] || s);
  const removed = [...prevSet].filter((s) => !curSet.has(s)).map((s) => labels[s] || s);

  return {
    added,
    removed,
    scoreDelta: (current.score || 0) - (previous.score || 0),
    gradeFrom: previous.grade,
    gradeTo: current.grade
  };
}

